# NESTIFY

NESTIFY is a Jakarta Servlet/JSP marketplace for verified PG and hostel listings. Owners can register, verify email, submit identity/ownership documents and listings; administrators review them before public display. Tenants can search, save and enquire.

## Requirements

- JDK 17
- Maven 3.9+
- MySQL 8.0+
- Apache Tomcat 10.1

## Configure and run

1. Create a database user with access to the `nestify` database. Run `sql/schema.sql`, then `sql/seed.sql` using MySQL.
2. Copy `config.properties.example` to a file outside the repository, for example `C:\ProgramData\Nestify\config.properties`. Set JDBC credentials, an upload directory outside Tomcat's `webapps`, and SMTP credentials. Set `NESTIFY_CONFIG` to this file's absolute path in Tomcat's environment. Alternatively, use `DB_URL`, `DB_USER`, `DB_PASSWORD`, `UPLOAD_PATH`, `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD` and `MAIL_FROM` environment variables.
3. Set `admin.email=admin@nestify.local` and a unique `admin.password` of at least 12 characters in that external file for first startup. The listener enables that seeded account with a BCrypt password. Remove the password setting after bootstrap.
4. Build with `mvn clean package`; deploy `target\nestify.war` to Tomcat 10.1 and start Tomcat.
5. Browse to `http://localhost:8080/nestify/`. Sign in as `admin@nestify.local` using the password you set only in the external configuration. Seeded approved listings use locally bundled sample room photos from Pexels until owners upload their own property photos. Listing cards show the host name; listing details show the host's click-to-call mobile number. Seed contact details are demo-only. The sample photos are licensed under the [Pexels license](https://www.pexels.com/license/); their source files are linked in `src/main/webapp/assets/images/README.txt`. For production, remove demo rows and upload real listing photos.

Email verification sends an expiring OTP when SMTP is configured. Without SMTP, registration is not completed by a success-shaped fallback: the application logs the send failure and displays a retryable error. Upload limits are configured in the listing and KYC handlers. KYC files are stored outside the web application and available only through an authorized controller.

## Security and configuration

All credentials belong in the external config file or environment, never in source control. Use TLS for MySQL, SMTP and the public site. Restrict upload-directory filesystem permissions, configure a production CSP domain if required, and back up the database and upload path together. The default security headers use a self-only CSP. Change the administrator bootstrap password immediately and remove its config entry.

## Tests

Run `mvn test`. Tests exercise password/OTP utilities and service validation without requiring MySQL. Integration tests for DAOs require a configured MySQL instance and a disposable test schema.
