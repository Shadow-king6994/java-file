package com.nestify.listener;

import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.http.HttpSessionEvent;
import jakarta.servlet.http.HttpSessionListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@WebListener
public class SessionListener implements HttpSessionListener {
    private static final Logger LOG = LoggerFactory.getLogger(SessionListener.class);
    @Override public void sessionCreated(HttpSessionEvent event) { LOG.debug("Session created"); }
    @Override public void sessionDestroyed(HttpSessionEvent event) { LOG.debug("Session expired"); }
}
