package com.nestify.listener;

import com.nestify.util.DbUtil;
import com.nestify.util.PasswordUtil;
import com.zaxxer.hikari.HikariDataSource;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@WebListener
public class AppListener implements ServletContextListener {
    private static final Logger LOG = LoggerFactory.getLogger(AppListener.class);
    @Override public void contextInitialized(ServletContextEvent event) {
        DbUtil.initialize();
        String uploadPath = DbUtil.setting("upload.path");
        if (uploadPath == null || uploadPath.isBlank()) throw new IllegalStateException("upload.path must be configured outside the webapp");
        Path folder = Path.of(uploadPath).toAbsolutePath().normalize();
        if (folder.startsWith(Path.of(event.getServletContext().getRealPath("/")).toAbsolutePath().normalize()))
            throw new IllegalStateException("Upload directory must be outside the web application");
        try { Files.createDirectories(folder.resolve("kyc")); Files.createDirectories(folder.resolve("properties")); }
        catch (Exception e) { throw new IllegalStateException("Unable to create upload directories", e); }
        event.getServletContext().setAttribute("uploadRoot", folder.toString());
        bootstrapAdmin();
        LOG.info("NESTIFY initialized; private upload storage is configured");
    }
    private void bootstrapAdmin() {
        String email = DbUtil.setting("admin.email");
        String password = DbUtil.setting("admin.password");
        if (email == null || password == null || password.length() < 12) {
            LOG.info("Admin bootstrap skipped; configure admin.email and a 12+ character admin.password for initial setup");
            return;
        }
        try (var connection = DbUtil.getConnection();
             PreparedStatement find = connection.prepareStatement("SELECT id,role FROM users WHERE email=?")) {
            find.setString(1, email.trim().toLowerCase(java.util.Locale.ROOT));
            try (ResultSet result = find.executeQuery()) {
                if (result.next()) {
                    if (!"ADMIN".equals(result.getString("role"))) throw new IllegalStateException("Configured admin.email belongs to a non-admin user; choose a separate administrator address");
                    try (PreparedStatement update = connection.prepareStatement("UPDATE users SET role='ADMIN',password_hash=?,email_verified=TRUE,status='ACTIVE' WHERE id=?")) {
                        update.setString(1, PasswordUtil.hash(password)); update.setLong(2, result.getLong(1)); update.executeUpdate();
                    }
                } else {
                    try (PreparedStatement insert = connection.prepareStatement("INSERT INTO users(name,mobile,email,password_hash,role,email_verified) VALUES(?,?,?,?, 'ADMIN',TRUE)")) {
                        insert.setString(1, "NESTIFY Administrator"); insert.setString(2, "9999999999"); insert.setString(3, email.trim().toLowerCase(java.util.Locale.ROOT));
                        insert.setString(4, PasswordUtil.hash(password)); insert.executeUpdate();
                    }
                }
            }
        } catch (Exception e) { throw new IllegalStateException("Admin account bootstrap failed", e); }
    }
    @Override public void contextDestroyed(ServletContextEvent event) { DbUtil.shutdown(); }
}
