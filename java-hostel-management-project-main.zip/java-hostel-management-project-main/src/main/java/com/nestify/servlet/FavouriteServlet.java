package com.nestify.servlet;
import com.nestify.dao.impl.FavouriteDaoImpl;
import com.nestify.dao.impl.PropertyDaoImpl;
import com.nestify.model.User;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
@WebServlet("/favourite")
public class FavouriteServlet extends HttpServlet {
    private FavouriteDaoImpl favourites;
    @Override public void init(){favourites=new FavouriteDaoImpl(new PropertyDaoImpl());}
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException{
        if(req.getSession(false)==null||!(req.getSession(false).getAttribute("authUser") instanceof User user)||!"TENANT".equals(user.getRole())){res.sendRedirect(req.getContextPath()+"/login");return;}
        try{favourites.toggle(user.getId(),Long.parseLong(req.getParameter("propertyId")));res.sendRedirect(req.getContextPath()+"/listing?id="+req.getParameter("propertyId"));}
        catch(NumberFormatException e){res.sendError(400);}
    }
}
