package com.nestify.servlet;
import com.nestify.dao.impl.EnquiryDaoImpl;
import com.nestify.dao.impl.NotificationDaoImpl;
import com.nestify.dao.impl.PropertyDaoImpl;
import com.nestify.dao.impl.UserDaoImpl;
import com.nestify.model.Enquiry;
import com.nestify.model.User;
import com.nestify.service.EnquiryService;
import com.nestify.util.MailUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@WebServlet("/enquiry")
public class EnquiryServlet extends HttpServlet {
    private static final Logger LOG=LoggerFactory.getLogger(EnquiryServlet.class);
    private EnquiryService service;
    @Override public void init(){service=new EnquiryService(new EnquiryDaoImpl(),new PropertyDaoImpl(),new UserDaoImpl(),new NotificationDaoImpl(),new MailUtil());}
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException{
        try{
            Enquiry e=new Enquiry();e.setPropertyId(Long.parseLong(req.getParameter("propertyId")));
            if(req.getSession(false)!=null&&req.getSession(false).getAttribute("authUser") instanceof User u){if(!"TENANT".equals(u.getRole()))throw new IllegalArgumentException("Only tenants can send enquiries");e.setTenantId(u.getId());}
            e.setName(req.getParameter("name"));e.setMobile(req.getParameter("mobile"));e.setEmail(req.getParameter("email"));e.setGender(req.getParameter("gender"));e.setOccupation(req.getParameter("occupation"));e.setCollegeCompany(req.getParameter("collegeCompany"));e.setStayDuration(req.getParameter("stayDuration"));e.setRoomInterest(req.getParameter("roomInterest"));e.setMessage(req.getParameter("message"));e.setPreferredVisitSlot(req.getParameter("preferredVisitSlot"));
            if(req.getParameter("moveInDate")!=null&&!req.getParameter("moveInDate").isBlank())e.setMoveInDate(Date.valueOf(req.getParameter("moveInDate")));
            if(req.getParameter("preferredVisitDate")!=null&&!req.getParameter("preferredVisitDate").isBlank())e.setPreferredVisitDate(Date.valueOf(req.getParameter("preferredVisitDate")));
            if(req.getParameter("budget")!=null&&!req.getParameter("budget").isBlank())e.setBudget(new BigDecimal(req.getParameter("budget")));
            service.submit(e,req.getRemoteAddr());req.getSession().setAttribute("notice","Your enquiry has been sent to the owner.");res.sendRedirect(req.getContextPath()+"/listing?id="+e.getPropertyId());
        }catch(IllegalArgumentException e){req.getSession().setAttribute("error",e.getMessage());res.sendRedirect(req.getContextPath()+"/listing?id="+req.getParameter("propertyId"));}
        catch(Exception e){LOG.error("Enquiry submission failed",e);req.getSession().setAttribute("error","Your enquiry could not be sent. Please try again.");res.sendRedirect(req.getContextPath()+"/listing?id="+req.getParameter("propertyId"));}
    }
}
