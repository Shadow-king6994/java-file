package com.nestify.servlet;
import com.nestify.dao.PropertyDao;
import com.nestify.dao.impl.PropertyDaoImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
@WebServlet("/home")
public class HomeServlet extends HttpServlet {
    private PropertyDao properties;
    @Override public void init(){properties=new PropertyDaoImpl();}
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
        req.setAttribute("featured",properties.featured(6));req.getRequestDispatcher("/WEB-INF/views/index.jsp").forward(req,res);
    }
}
