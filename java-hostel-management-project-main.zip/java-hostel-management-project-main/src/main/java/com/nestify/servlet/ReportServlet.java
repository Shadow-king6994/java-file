package com.nestify.servlet;
import com.nestify.dao.impl.ReportDaoImpl;
import com.nestify.model.Report;
import com.nestify.model.User;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@WebServlet("/report")
public class ReportServlet extends HttpServlet {
    private static final Logger LOG=LoggerFactory.getLogger(ReportServlet.class);
    private ReportDaoImpl reports;
    @Override public void init(){reports=new ReportDaoImpl();}
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException{
        try{Report r=new Report();r.setPropertyId(Long.parseLong(req.getParameter("propertyId")));r.setReason(req.getParameter("reason"));r.setDetails(req.getParameter("details"));if(req.getSession(false)!=null&&req.getSession(false).getAttribute("authUser") instanceof User u)r.setReporterId(u.getId());reports.create(r);req.getSession().setAttribute("notice","Thanks. Your report was sent to our safety team.");}
        catch(Exception e){LOG.error("Listing report submission failed",e);req.getSession().setAttribute("error","We could not submit this report. Please try again.");}
        res.sendRedirect(req.getContextPath()+"/listing?id="+req.getParameter("propertyId"));
    }
}
