package com.nestify.servlet;
import com.nestify.dao.*;
import com.nestify.dao.impl.*;
import com.nestify.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
@WebServlet("/owner/*")
public class OwnerServlet extends HttpServlet {
    private PropertyDao properties;private EnquiryDao enquiries;private KycDao kyc;private VisitDao visits;
    @Override public void init(){properties=new PropertyDaoImpl();enquiries=new EnquiryDaoImpl();kyc=new KycDaoImpl();visits=new VisitDaoImpl();}
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
        User owner=(User)req.getSession().getAttribute("authUser");String path=req.getPathInfo();
        if("/dashboard".equals(path)){req.setAttribute("properties",properties.findByOwner(owner.getId()));req.setAttribute("kyc",kyc.findByOwner(owner.getId()).orElse(null));req.getRequestDispatcher("/WEB-INF/views/owner/dashboard.jsp").forward(req,res);}
        else if("/enquiries".equals(path)){req.setAttribute("enquiries",enquiries.findForOwner(owner.getId()));req.setAttribute("visits",visits.findForOwner(owner.getId()));req.getRequestDispatcher("/WEB-INF/views/owner/enquiries.jsp").forward(req,res);}
        else if("/onboarding".equals(path)){req.setAttribute("kyc",kyc.findByOwner(owner.getId()).orElse(null));req.getRequestDispatcher("/WEB-INF/views/owner/onboarding.jsp").forward(req,res);}
        else res.sendError(404);
    }
}
