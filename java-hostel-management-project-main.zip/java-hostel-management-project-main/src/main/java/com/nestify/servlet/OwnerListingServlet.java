package com.nestify.servlet;
import com.nestify.dao.impl.KycDaoImpl;
import com.nestify.dao.impl.PropertyDaoImpl;
import com.nestify.model.*;
import com.nestify.service.ListingService;
import com.nestify.util.FileUtil;
import com.nestify.util.ValidationUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.sql.Date;
import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@WebServlet("/owner/listing/*")
@MultipartConfig(maxFileSize=5*1024*1024,maxRequestSize=70*1024*1024)
public class OwnerListingServlet extends HttpServlet {
    private static final Logger LOG=LoggerFactory.getLogger(OwnerListingServlet.class);
    private ListingService service;private KycDaoImpl kyc;private PropertyDaoImpl properties;
    @Override public void init(){properties=new PropertyDaoImpl();service=new ListingService(properties);kyc=new KycDaoImpl();}
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
        req.setAttribute("amenityOptions",List.of("WiFi","AC","Laundry","Power backup","CCTV","Geyser","Parking","Housekeeping","Attached bath","Fridge","TV","Study table"));
        String action=req.getPathInfo();User user=(User)req.getSession().getAttribute("authUser");
        var verification=kyc.findByOwner(user.getId()).orElse(null);
        if(verification==null||!"APPROVED".equals(verification.getStatus())){res.sendRedirect(req.getContextPath()+"/owner/onboarding");return;}
        if("/edit".equals(action)){
            try{long id=Long.parseLong(req.getParameter("id"));Property p=properties.findById(id).orElseThrow(()->new IllegalArgumentException("Listing not found"));if(p.getOwnerId()!=user.getId()){res.sendError(403);return;}req.setAttribute("property",p);}
            catch(IllegalArgumentException e){res.sendError(404);return;}
        }
        req.getRequestDispatcher("/WEB-INF/views/owner/listing-form.jsp").forward(req,res);
    }
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
        User user=(User)req.getSession().getAttribute("authUser");
        try{
            var verification=kyc.findByOwner(user.getId()).orElseThrow(()->new IllegalArgumentException("Complete owner verification before creating a listing."));
            if(!"APPROVED".equals(verification.getStatus()))throw new IllegalArgumentException("Your owner verification must be approved before you can publish a listing.");
            Property p=new Property();p.setOwnerId(user.getId());p.setTitle(req.getParameter("title"));p.setPropertyType(req.getParameter("propertyType"));p.setSuitableFor(req.getParameter("suitableFor"));
            if("/edit".equals(req.getPathInfo())){p.setId(Long.parseLong(req.getParameter("propertyId")));Property original=properties.findById(p.getId()).orElseThrow(()->new IllegalArgumentException("Listing not found"));if(original.getOwnerId()!=user.getId())throw new IllegalArgumentException("Listing not found");p.setPhotos(original.getPhotos());req.setAttribute("property",original);}
            p.setCity(req.getParameter("city"));p.setLocality(req.getParameter("locality"));p.setFullAddress(req.getParameter("fullAddress"));p.setPincode(req.getParameter("pincode"));
            p.setTotalRooms(Integer.parseInt(req.getParameter("totalRooms")));p.setAvailableFrom(com.nestify.service.ListingService.parseDate(req.getParameter("availableFrom"),"Available from"));
            p.setFoodOption(req.getParameter("foodOption"));p.setMealDetails(req.getParameter("mealDetails"));p.setCurfew(req.getParameter("curfew"));p.setVisitorRules(req.getParameter("visitorRules"));
            p.setSmokingAllowed(req.getParameter("smokingAllowed")!=null);p.setAlcoholAllowed(req.getParameter("alcoholAllowed")!=null);p.setPetsAllowed(req.getParameter("petsAllowed")!=null);
            p.setNoticePeriod(req.getParameter("noticePeriod"));p.setMaintenanceCharges(new BigDecimal(Optional.ofNullable(req.getParameter("maintenanceCharges")).filter(s->!s.isBlank()).orElse("0")));
            p.setDescription(req.getParameter("description"));p.setNearbyLandmarks(req.getParameter("nearbyLandmarks"));
            String[] sharing=req.getParameterValues("sharing"),rents=req.getParameterValues("rent"),deposits=req.getParameterValues("deposit");
            if(sharing==null||rents==null||deposits==null||sharing.length!=rents.length||sharing.length!=deposits.length||sharing.length>4)throw new IllegalArgumentException("Add valid room type details");
            for(int i=0;i<sharing.length;i++){RoomType r=new RoomType();r.setSharing(sharing[i]);r.setRent(new BigDecimal(rents[i]));r.setDeposit(new BigDecimal(deposits[i]));r.setAvailableCount(1);p.getRoomTypes().add(r);}
            String[] amenities=req.getParameterValues("amenities");if(amenities!=null)p.setAmenities(Arrays.asList(amenities));
            Path directory=Path.of((String)getServletContext().getAttribute("uploadRoot")).resolve("properties");
            List<Photo> uploaded=new ArrayList<>();for(Part part:req.getParts())if("photos".equals(part.getName())&&part.getSize()>0){Photo photo=new Photo();photo.setFilePath("properties/"+FileUtil.saveImage(part,directory));uploaded.add(photo);}
            if(!uploaded.isEmpty())p.setPhotos(uploaded);
            service.create(p);req.getSession().setAttribute("notice","Listing submitted for review. It will be visible again after approval.");res.sendRedirect(req.getContextPath()+"/owner/dashboard");
        }catch(IllegalArgumentException e){req.setAttribute("error",e.getMessage());req.setAttribute("amenityOptions",List.of("WiFi","AC","Laundry","Power backup","CCTV","Geyser","Parking","Housekeeping","Attached bath","Fridge","TV","Study table"));req.getRequestDispatcher("/WEB-INF/views/owner/listing-form.jsp").forward(req,res);}
        catch(Exception e){LOG.error("Listing submission failed for owner {}",user.getId(),e);req.setAttribute("error","Listing could not be submitted. Please check each field and try again.");req.setAttribute("amenityOptions",List.of("WiFi","AC","Laundry","Power backup","CCTV","Geyser","Parking","Housekeeping","Attached bath","Fridge","TV","Study table"));req.getRequestDispatcher("/WEB-INF/views/owner/listing-form.jsp").forward(req,res);}
    }
}
