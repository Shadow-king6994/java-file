package com.nestify.servlet;
import com.nestify.dao.impl.UserDaoImpl;
import com.nestify.model.User;
import com.nestify.service.AuthService;
import com.nestify.util.MailUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@WebServlet("/auth/*")
public class AuthServlet extends HttpServlet {
    private static final Logger LOG=LoggerFactory.getLogger(AuthServlet.class);
    private AuthService auth;
    @Override public void init(){auth=new AuthService(new UserDaoImpl(),new MailUtil());}
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException{
        String action=req.getPathInfo()==null?"":req.getPathInfo();
        try{
            switch(action){
                case "/register" -> register(req,res);
                case "/login" -> login(req,res);
                case "/verify" -> verify(req,res);
                case "/resend" -> resend(req,res);
                case "/logout" -> logout(req,res);
                default -> res.sendError(404);
            }
        }catch(IllegalArgumentException e){req.setAttribute("error",e.getMessage());forward(req,res,pageFor(action));}
        catch(Exception e){LOG.error("Authentication request failed: {}",action,e);req.setAttribute("error","We could not complete that request. Check your details and try again.");forward(req,res,pageFor(action));}
    }
    private void register(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
        long id=auth.register(req.getParameter("name"),req.getParameter("mobile"),req.getParameter("email"),req.getParameter("password"),req.getParameter("role"));
        req.getSession().setAttribute("pendingUserId",id);req.getSession().setAttribute("pendingEmail",req.getParameter("email").trim());
        try{auth.sendOtp(id,req.getParameter("email").trim());}
        catch(Exception e){LOG.error("Account created but verification email could not be sent",e);req.setAttribute("error","Your account was created, but the verification email could not be sent. Check the email service and use the resend option.");forward(req,res,"/WEB-INF/views/verify-otp.jsp");return;}
        res.sendRedirect(req.getContextPath()+"/verify-otp");
    }
    private void login(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException{
        Optional<User> result=auth.authenticate(req.getParameter("email"),req.getParameter("password"));
        if(result.isEmpty()){req.setAttribute("error","Email or password is incorrect, or this account is locked.");forward(req,res,"/WEB-INF/views/login.jsp");return;}
        User user=result.get();
        if(!user.isEmailVerified()){req.setAttribute("error","Verify your email before signing in.");req.getSession().setAttribute("pendingUserId",user.getId());req.getSession().setAttribute("pendingEmail",user.getEmail());forward(req,res,"/WEB-INF/views/verify-otp.jsp");return;}
        establishSession(req,user);res.sendRedirect(req.getContextPath()+destination(user));
    }
    private void verify(HttpServletRequest req,HttpServletResponse res)throws IOException{
        Object raw=req.getSession().getAttribute("pendingUserId");if(!(raw instanceof Long id)){res.sendRedirect(req.getContextPath()+"/register");return;}
        User user=auth.verify(id,req.getParameter("otp"));establishSession(req,user);res.sendRedirect(req.getContextPath()+destination(user));
    }
    private void resend(HttpServletRequest req,HttpServletResponse res)throws Exception{
        Object raw=req.getSession().getAttribute("pendingUserId");Object email=req.getSession().getAttribute("pendingEmail");
        if(!(raw instanceof Long id)||!(email instanceof String address))throw new IllegalArgumentException("Start registration again to request a new code");
        auth.sendOtp(id,address);req.getSession().setAttribute("notice","A new code was sent to your email.");res.sendRedirect(req.getContextPath()+"/verify-otp");
    }
    private void logout(HttpServletRequest req,HttpServletResponse res)throws IOException{if(req.getSession(false)!=null)req.getSession(false).invalidate();res.sendRedirect(req.getContextPath()+"/");}
    private void establishSession(HttpServletRequest req,User user){
        HttpSession old=req.getSession(false);if(old!=null)old.invalidate();HttpSession session=req.getSession(true);
        session.setAttribute("authUser",user);session.setAttribute("csrfToken",java.util.UUID.randomUUID().toString());
    }
    private String destination(User user){return switch(user.getRole()){case "OWNER"->"/owner/dashboard";case "ADMIN"->"/admin/dashboard";default->"/tenant/dashboard";};}
    private String pageFor(String action){return switch(action){case "/register"->"/WEB-INF/views/register.jsp";case "/verify","/resend"->"/WEB-INF/views/verify-otp.jsp";default->"/WEB-INF/views/login.jsp";};}
    private void forward(HttpServletRequest req,HttpServletResponse res,String page)throws ServletException,IOException{req.getRequestDispatcher(page).forward(req,res);}
}
