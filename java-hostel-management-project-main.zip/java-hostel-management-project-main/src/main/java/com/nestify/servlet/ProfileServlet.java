package com.nestify.servlet;
import com.nestify.dao.impl.UserDaoImpl;
import com.nestify.model.User;
import com.nestify.util.ValidationUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
@WebServlet("/tenant/profile")
public class ProfileServlet extends HttpServlet {
    private UserDaoImpl users;
    @Override public void init(){users=new UserDaoImpl();}
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
        User user=(User)req.getSession().getAttribute("authUser");
        try{String name=ValidationUtil.required(req.getParameter("name"),"Name",120);String mobile=ValidationUtil.mobile(req.getParameter("mobile"));users.updateProfile(user.getId(),name,mobile);user.setName(name);user.setMobile(mobile);req.getSession().setAttribute("authUser",user);req.getSession().setAttribute("notice","Your profile was updated.");res.sendRedirect(req.getContextPath()+"/tenant/dashboard");}
        catch(IllegalArgumentException e){req.getSession().setAttribute("error",e.getMessage());res.sendRedirect(req.getContextPath()+"/tenant/dashboard");}
    }
}
