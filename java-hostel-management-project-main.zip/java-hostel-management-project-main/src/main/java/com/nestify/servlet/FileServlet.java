package com.nestify.servlet;
import com.nestify.model.User;
import com.nestify.util.DbUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.nio.file.*;
import java.sql.*;
@WebServlet("/files/*")
public class FileServlet extends HttpServlet {
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException{
        String relative=req.getPathInfo();if(relative==null||relative.length()<2){res.sendError(404);return;}
        relative=relative.substring(1);
        if(relative.contains("..")||relative.startsWith("/")||relative.indexOf('\\')>=0){res.sendError(404);return;}
        User user=req.getSession(false)!=null&&req.getSession(false).getAttribute("authUser") instanceof User u?u:null;
        boolean authorized=false;
        try(Connection c=DbUtil.getConnection()){
            if(relative.startsWith("kyc/")){
                if(user==null){res.sendError(403);return;}
                String sql="SELECT user_id FROM owner_kyc WHERE id_front_path=? OR id_back_path=? OR selfie_path=? OR ownership_proof_path=?";
                try(PreparedStatement p=c.prepareStatement(sql)){for(int i=1;i<=4;i++)p.setString(i,relative);try(ResultSet r=p.executeQuery()){while(r.next())if("ADMIN".equals(user.getRole())||user.getId()==r.getLong(1))authorized=true;}}
                res.setHeader("Content-Disposition","attachment; filename=\""+relative.substring(relative.lastIndexOf('/')+1).replaceAll("[^A-Za-z0-9._-]","_")+"\"");
                res.setHeader("Cache-Control","private, no-store");
            }else if(relative.startsWith("properties/")){
                String sql="SELECT p.status,p.owner_id FROM property_photos ph JOIN properties p ON p.id=ph.property_id WHERE ph.file_path=?";
                try(PreparedStatement p=c.prepareStatement(sql)){p.setString(1,relative);try(ResultSet r=p.executeQuery()){if(r.next())authorized="APPROVED".equals(r.getString(1))||(user!=null&&(user.getId()==r.getLong(2)||"ADMIN".equals(user.getRole())));}}
            }
        }catch(SQLException e){throw new ServletException("File authorization failed",e);}
        if(!authorized){res.sendError(404);return;}
        Path root=Path.of((String)getServletContext().getAttribute("uploadRoot")).toAbsolutePath().normalize();Path file=root.resolve(relative).normalize();
        if(!file.startsWith(root)||!Files.isRegularFile(file)){res.sendError(404);return;}
        String extension=file.getFileName().toString().toLowerCase(java.util.Locale.ROOT);
        res.setContentType(extension.endsWith(".png")?"image/png":extension.endsWith(".webp")?"image/webp":extension.endsWith(".jpg")||extension.endsWith(".jpeg")?"image/jpeg":"application/octet-stream");
        res.setContentLengthLong(Files.size(file));try(InputStream in=Files.newInputStream(file);OutputStream out=res.getOutputStream()){in.transferTo(out);}
    }
}
