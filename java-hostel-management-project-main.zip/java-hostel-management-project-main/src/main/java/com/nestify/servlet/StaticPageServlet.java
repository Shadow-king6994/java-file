package com.nestify.servlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
@WebServlet(urlPatterns={"/about","/contact","/terms","/privacy","/safety"})
public class StaticPageServlet extends HttpServlet {
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
        String path=req.getServletPath().substring(1);req.setAttribute("pageTitle",switch(path){case "safety"->"Safety tips";default->Character.toUpperCase(path.charAt(0))+path.substring(1);});
        req.getRequestDispatcher("/WEB-INF/views/info.jsp").forward(req,res);
    }
}
