package com.nestify.servlet;
import com.nestify.dao.impl.PropertyDaoImpl;
import com.nestify.service.ListingService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.*;
@WebServlet("/search")
public class SearchServlet extends HttpServlet {
    private ListingService listings;
    @Override public void init(){listings=new ListingService(new PropertyDaoImpl());}
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
        try{
            Map<String,String> filters=new HashMap<>();for(String key:List.of("city","locality","type","gender","minPrice","maxPrice","food","sort","sharing","amenity")){String v=req.getParameter(key);if(v!=null)filters.put(key,v);}
            if("on".equals(req.getParameter("verified")))filters.put("verified","true");
            int page;try{page=Integer.parseInt(Optional.ofNullable(req.getParameter("page")).orElse("1"));}catch(NumberFormatException e){page=1;}
            var found=new ArrayList<>(listings.search(filters,page));boolean hasNext=found.size()>12;
            if(hasNext)found.remove(found.size()-1);
            req.setAttribute("properties",found);req.setAttribute("hasNext",hasNext);req.setAttribute("page",Math.max(1,page));req.setAttribute("filters",filters);
            req.getRequestDispatcher("/WEB-INF/views/search.jsp").forward(req,res);
        }catch(IllegalArgumentException e){req.setAttribute("error",e.getMessage());req.setAttribute("properties",List.of());req.getRequestDispatcher("/WEB-INF/views/search.jsp").forward(req,res);}
    }
}
