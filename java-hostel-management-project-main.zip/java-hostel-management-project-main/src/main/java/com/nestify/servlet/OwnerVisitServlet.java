package com.nestify.servlet;
import com.nestify.dao.impl.VisitDaoImpl;
import com.nestify.model.User;
import com.nestify.util.ValidationUtil;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
@WebServlet("/owner/visit")
public class OwnerVisitServlet extends HttpServlet {
    private VisitDaoImpl visits;
    @Override public void init(){visits=new VisitDaoImpl();}
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException{
        User owner=(User)req.getSession().getAttribute("authUser");
        try{long id=Long.parseLong(req.getParameter("id"));String status=ValidationUtil.enumValue(req.getParameter("status"),"visit status","CONFIRMED","DECLINED");visits.setOwnerStatus(owner.getId(),id,status);req.getSession().setAttribute("notice","Visit request updated.");}
        catch(IllegalArgumentException e){req.getSession().setAttribute("error",e.getMessage());}
        res.sendRedirect(req.getContextPath()+"/owner/enquiries");
    }
}
