package com.nestify.servlet;
import com.nestify.dao.impl.*;
import com.nestify.model.*;
import com.nestify.util.MailUtil;
import com.nestify.util.ValidationUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@WebServlet("/admin/*")
public class AdminServlet extends HttpServlet {
    private static final Logger LOG=LoggerFactory.getLogger(AdminServlet.class);
    private PropertyDaoImpl properties;private KycDaoImpl kyc;private UserDaoImpl users;private ReportDaoImpl reports;private AdminActionDaoImpl audit;private NotificationDaoImpl notifications;private MailUtil mail;
    @Override public void init(){properties=new PropertyDaoImpl();kyc=new KycDaoImpl();users=new UserDaoImpl();reports=new ReportDaoImpl();audit=new AdminActionDaoImpl();notifications=new NotificationDaoImpl();mail=new MailUtil();}
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
        String path=req.getPathInfo();User admin=(User)req.getSession().getAttribute("authUser");
        switch(path==null?"/dashboard":path){
            case "/dashboard" -> {req.setAttribute("kycQueue",kyc.pending());req.setAttribute("propertyQueue",properties.pending());req.setAttribute("audit",audit.recent(12));req.getRequestDispatcher("/WEB-INF/views/admin/dashboard.jsp").forward(req,res);}
            case "/verification-queue" -> {req.setAttribute("kycQueue",kyc.pending());req.setAttribute("propertyQueue",properties.pending());req.getRequestDispatcher("/WEB-INF/views/admin/verification-queue.jsp").forward(req,res);}
            case "/review" -> {
                String type=req.getParameter("type");long id=parseId(req.getParameter("id"));
                if("kyc".equals(type)){OwnerKyc found=kyc.pending().stream().filter(k->k.getId()==id).findFirst().orElse(null);if(found==null){res.sendError(404);return;}req.setAttribute("kyc",found);}
                else if("property".equals(type)){Property found=properties.pending().stream().filter(p->p.getId()==id).findFirst().orElse(null);if(found==null){res.sendError(404);return;}req.setAttribute("property",found);}
                else{res.sendError(400);return;}
                req.setAttribute("type",type);req.getRequestDispatcher("/WEB-INF/views/admin/review.jsp").forward(req,res);
            }
            case "/users" -> {req.setAttribute("users",users.findAll());req.getRequestDispatcher("/WEB-INF/views/admin/users.jsp").forward(req,res);}
            case "/reports" -> {req.setAttribute("reports",reports.findOpen());req.getRequestDispatcher("/WEB-INF/views/admin/reports.jsp").forward(req,res);}
            default -> res.sendError(404);
        }
    }
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException{
        String path=req.getPathInfo();User admin=(User)req.getSession().getAttribute("authUser");
        try{
            if("/review".equals(path))review(req,admin);
            else if("/users".equals(path))changeUser(req,admin);
            else if("/reports".equals(path))changeReport(req,admin);
            else{res.sendError(404);return;}
            req.getSession().setAttribute("notice","Review action saved.");res.sendRedirect(req.getContextPath()+("/reports".equals(path)?"/admin/reports":"/users".equals(path)?"/admin/users":"/admin/verification-queue"));
        }catch(IllegalArgumentException e){req.getSession().setAttribute("error",e.getMessage());res.sendRedirect(req.getContextPath()+"/admin/verification-queue");}
        catch(Exception e){LOG.error("Admin action failed for {}",path,e);req.getSession().setAttribute("error","The action could not be saved. Please try again.");res.sendRedirect(req.getContextPath()+"/admin/dashboard");}
    }
    private void review(HttpServletRequest req,User admin)throws Exception{
        String type=ValidationUtil.enumValue(req.getParameter("type"),"review type","KYC","PROPERTY");
        String status=ValidationUtil.enumValue(req.getParameter("status"),"status","APPROVED","REJECTED","NEEDS_MORE_INFO");
        String reason=req.getParameter("reason")==null?"":req.getParameter("reason").trim();
        if(!"APPROVED".equals(status)&&reason.isBlank())throw new IllegalArgumentException("Add a reason for rejection or requested information.");
        if(reason.length()>1000)throw new IllegalArgumentException("Review reason is too long");
        long id=parseId(req.getParameter("id"));
        long ownerId;String email;String entity;
        if("KYC".equals(type)){
            OwnerKyc record=kyc.pending().stream().filter(k->k.getId()==id).findFirst().orElseThrow(()->new IllegalArgumentException("Verification item no longer needs review"));
            ownerId=record.getUserId();kyc.review(id,admin.getId(),status,reason);entity="identity verification";
        }else{
            Property record=properties.pending().stream().filter(p->p.getId()==id).findFirst().orElseThrow(()->new IllegalArgumentException("Listing no longer needs review"));
            if("APPROVED".equals(status)&&kyc.findByOwner(record.getOwnerId()).filter(k->"APPROVED".equals(k.getStatus())).isEmpty())
                throw new IllegalArgumentException("Approve the owner's identity verification before approving this listing.");
            ownerId=record.getOwnerId();properties.setStatus(id,status,admin.getId(),reason);entity="listing";
        }
        User owner=users.findById(ownerId).orElseThrow(()->new IllegalStateException("Owner account was not found"));email=owner.getEmail();
        String body="Your "+entity+" review is "+status.replace('_',' ').toLowerCase(java.util.Locale.ROOT)+"."+ (reason.isBlank()?"":" Reviewer note: "+reason);
        notifications.create(ownerId,"NESTIFY verification update",body);
        try{mail.send(email,"NESTIFY verification update",body);}catch(Exception e){LOG.error("Review saved but owner email notification failed for user {}",ownerId,e);}
    }
    private void changeUser(HttpServletRequest req,User admin){
        long id=parseId(req.getParameter("id"));if(id==admin.getId())throw new IllegalArgumentException("You cannot disable your own administrator account");
        String status=ValidationUtil.enumValue(req.getParameter("status"),"user status","ACTIVE","DISABLED");
        users.setStatus(id,status);AdminAction a=new AdminAction();a.setAdminId(admin.getId());a.setTargetType("USER");a.setTargetId(id);a.setAction(status);a.setReason("Changed from admin user management");audit.create(a);
    }
    private void changeReport(HttpServletRequest req,User admin){
        long id=parseId(req.getParameter("id"));String status=ValidationUtil.enumValue(req.getParameter("status"),"report status","REVIEWED","DISMISSED");
        reports.setStatus(id,status);AdminAction a=new AdminAction();a.setAdminId(admin.getId());a.setTargetType("REPORT");a.setTargetId(id);a.setAction(status);a.setReason("Changed from admin report review");audit.create(a);
    }
    private long parseId(String value){try{long id=Long.parseLong(value);if(id<1)throw new NumberFormatException();return id;}catch(Exception e){throw new IllegalArgumentException("Invalid record id");}}
}
