package com.nestify.servlet;
import com.nestify.dao.impl.VisitDaoImpl;
import com.nestify.model.User;
import com.nestify.model.Visit;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Date;
@WebServlet("/visit")
public class VisitServlet extends HttpServlet {
    private VisitDaoImpl visits;
    @Override public void init(){visits=new VisitDaoImpl();}
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException{
        if(req.getSession(false)==null||!(req.getSession(false).getAttribute("authUser") instanceof User user)||!"TENANT".equals(user.getRole())){res.sendRedirect(req.getContextPath()+"/login");return;}
        try{Visit visit=new Visit();visit.setTenantId(user.getId());visit.setPropertyId(Long.parseLong(req.getParameter("propertyId")));visit.setRequestedDate(Date.valueOf(req.getParameter("requestedDate")));visit.setTimeSlot(req.getParameter("timeSlot"));visits.create(visit);req.getSession().setAttribute("notice","Visit request sent.");res.sendRedirect(req.getContextPath()+"/listing?id="+visit.getPropertyId());}
        catch(IllegalArgumentException e){req.getSession().setAttribute("error","Please choose a valid date and time slot.");res.sendRedirect(req.getContextPath()+"/listing?id="+req.getParameter("propertyId"));}
    }
}
