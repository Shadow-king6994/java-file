package com.nestify.servlet;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
@WebServlet(urlPatterns={"/login","/register","/verify-otp"})
public class AuthPageServlet extends HttpServlet {
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
        String page=switch(req.getServletPath()){case "/register"->"register";case "/verify-otp"->"verify-otp";default->"login";};
        req.getRequestDispatcher("/WEB-INF/views/"+page+".jsp").forward(req,res);
    }
}
