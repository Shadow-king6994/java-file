package com.nestify.servlet;
import com.nestify.dao.impl.KycDaoImpl;
import com.nestify.model.OwnerKyc;
import com.nestify.model.User;
import com.nestify.service.KycService;
import com.nestify.util.FileUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.nio.file.Path;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@WebServlet("/owner/kyc")
@MultipartConfig(maxFileSize=5*1024*1024,maxRequestSize=25*1024*1024)
public class KycServlet extends HttpServlet {
    private static final Logger LOG=LoggerFactory.getLogger(KycServlet.class);
    private KycService service;private KycDaoImpl dao;
    @Override public void init(){dao=new KycDaoImpl();service=new KycService(dao);}
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException{
        User user=(User)req.getSession().getAttribute("authUser");Path root=Path.of((String)getServletContext().getAttribute("uploadRoot")).resolve("kyc");
        try{
            OwnerKyc k=new OwnerKyc();k.setUserId(user.getId());k.setIdType(req.getParameter("idType"));k.setIdNumber(req.getParameter("idNumber"));
            k.setIdFrontPath("kyc/"+FileUtil.saveImage(req.getPart("idFront"),root));
            k.setIdBackPath("kyc/"+FileUtil.saveImage(req.getPart("idBack"),root));
            k.setSelfiePath("kyc/"+FileUtil.saveImage(req.getPart("selfie"),root));
            k.setOwnershipProofPath("kyc/"+FileUtil.saveImage(req.getPart("ownershipProof"),root));
            service.submit(k);req.getSession().setAttribute("notice","Your verification documents are submitted for review.");res.sendRedirect(req.getContextPath()+"/owner/dashboard");
        }catch(IllegalArgumentException e){req.setAttribute("error",e.getMessage());req.setAttribute("kyc",dao.findByOwner(user.getId()).orElse(null));req.getRequestDispatcher("/WEB-INF/views/owner/onboarding.jsp").forward(req,res);}
        catch(Exception e){LOG.error("KYC submission failed for owner {}",user.getId(),e);req.setAttribute("error","Documents could not be submitted. Please try again.");req.getRequestDispatcher("/WEB-INF/views/owner/onboarding.jsp").forward(req,res);}
    }
}
