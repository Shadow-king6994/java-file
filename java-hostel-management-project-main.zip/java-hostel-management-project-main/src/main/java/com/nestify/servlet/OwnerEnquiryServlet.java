package com.nestify.servlet;
import com.nestify.dao.impl.EnquiryDaoImpl;
import com.nestify.model.User;
import com.nestify.util.ValidationUtil;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
@WebServlet("/owner/enquiry")
public class OwnerEnquiryServlet extends HttpServlet {
    private EnquiryDaoImpl enquiries;
    @Override public void init(){enquiries=new EnquiryDaoImpl();}
    @Override protected void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException{
        User owner=(User)req.getSession().getAttribute("authUser");
        try{long id=Long.parseLong(req.getParameter("id"));String status=ValidationUtil.enumValue(req.getParameter("status"),"enquiry status","CONTACTED","CLOSED");enquiries.setOwnerStatus(owner.getId(),id,status);req.getSession().setAttribute("notice","Enquiry status updated.");}
        catch(IllegalArgumentException e){req.getSession().setAttribute("error",e.getMessage());}
        res.sendRedirect(req.getContextPath()+"/owner/enquiries");
    }
}
