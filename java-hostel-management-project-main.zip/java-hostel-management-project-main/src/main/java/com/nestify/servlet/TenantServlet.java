package com.nestify.servlet;
import com.nestify.dao.impl.*;
import com.nestify.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
@WebServlet("/tenant/dashboard")
public class TenantServlet extends HttpServlet {
    private FavouriteDaoImpl favourites;private EnquiryDaoImpl enquiries;private VisitDaoImpl visits;private NotificationDaoImpl notifications;
    @Override public void init(){var properties=new PropertyDaoImpl();favourites=new FavouriteDaoImpl(properties);enquiries=new EnquiryDaoImpl();visits=new VisitDaoImpl();notifications=new NotificationDaoImpl();}
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
        User user=(User)req.getSession().getAttribute("authUser");req.setAttribute("favourites",favourites.findForUser(user.getId()));req.setAttribute("enquiries",enquiries.findForTenant(user.getId()));req.setAttribute("visits",visits.findForTenant(user.getId()));req.setAttribute("notifications",notifications.findForUser(user.getId()));
        req.getRequestDispatcher("/WEB-INF/views/tenant/dashboard.jsp").forward(req,res);
    }
}
