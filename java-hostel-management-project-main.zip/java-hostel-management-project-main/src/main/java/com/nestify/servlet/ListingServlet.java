package com.nestify.servlet;
import com.nestify.dao.*;
import com.nestify.dao.impl.*;
import com.nestify.model.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
@WebServlet("/listing")
public class ListingServlet extends HttpServlet {
    private PropertyDao properties;private FavouriteDao favourites;
    @Override public void init(){properties=new PropertyDaoImpl();favourites=new FavouriteDaoImpl(properties);}
    @Override protected void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
        try{long id=Long.parseLong(req.getParameter("id"));var property=properties.findPublicById(id);if(property.isEmpty()){res.sendError(404);return;}
            req.setAttribute("property",property.get());Object value=req.getSession(false)==null?null:req.getSession(false).getAttribute("authUser");
            if(value instanceof User user&&"TENANT".equals(user.getRole()))req.setAttribute("isFavourite",favourites.contains(user.getId(),id));
            req.getRequestDispatcher("/WEB-INF/views/listing.jsp").forward(req,res);
        }catch(NumberFormatException e){res.sendError(404);}
    }
}
