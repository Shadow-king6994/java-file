package com.nestify.util;

import org.mindrot.jbcrypt.BCrypt;

public final class PasswordUtil {
    private PasswordUtil() {}
    public static String hash(String password) { return BCrypt.hashpw(password, BCrypt.gensalt(12)); }
    public static boolean matches(String password, String hash) {
        if (password == null || hash == null) return false;
        try { return BCrypt.checkpw(password, hash); }
        catch (IllegalArgumentException e) { return false; }
    }
}
