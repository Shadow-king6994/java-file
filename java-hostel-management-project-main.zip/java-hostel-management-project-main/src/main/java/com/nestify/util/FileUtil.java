package com.nestify.util;

import jakarta.servlet.http.Part;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

public final class FileUtil {
    private static final long MAX_BYTES = 5L * 1024 * 1024;
    private FileUtil() {}
    public static String saveImage(Part part, Path directory) throws IOException {
        if (part == null || part.getSize() == 0 || part.getSize() > MAX_BYTES) throw new IllegalArgumentException("Each image must be between 1 byte and 5 MB");
        byte[] header;
        try (InputStream in = part.getInputStream()) { header = in.readNBytes(12); }
        String extension = imageExtension(header);
        Files.createDirectories(directory);
        String name = UUID.randomUUID() + "." + extension;
        Path original = directory.resolve(name).normalize();
        if (!original.getParent().equals(directory.normalize())) throw new IllegalArgumentException("Invalid upload path");
        try (InputStream input = part.getInputStream()) { Files.copy(input, original); }
        try {
            String resizedExtension = "webp".equals(extension) ? "jpg" : extension;
            resize(original, directory.resolve(UUID.randomUUID() + "-small." + resizedExtension));
            return name;
        } catch (RuntimeException e) {
            Files.deleteIfExists(original);
            throw e;
        }
    }
    private static String imageExtension(byte[] b) {
        if (b.length >= 3 && (b[0] & 255) == 0xFF && (b[1] & 255) == 0xD8 && (b[2] & 255) == 0xFF) return "jpg";
        if (b.length >= 8 && (b[0] & 255) == 0x89 && b[1] == 'P' && b[2] == 'N' && b[3] == 'G' && b[4] == 13 && b[5] == 10 && b[6] == 26 && b[7] == 10) return "png";
        if (b.length >= 12 && b[0] == 'R' && b[1] == 'I' && b[2] == 'F' && b[3] == 'F' && b[8] == 'W' && b[9] == 'E' && b[10] == 'B' && b[11] == 'P') return "webp";
        throw new IllegalArgumentException("Only JPEG, PNG, and WebP files are accepted");
    }
    private static void resize(Path source, Path target) {
        try (ImageInputStream input = javax.imageio.ImageIO.createImageInputStream(source.toFile())) {
            if (input == null) throw new IllegalArgumentException("Image could not be decoded");
            var readers = javax.imageio.ImageIO.getImageReaders(input);
            if (!readers.hasNext()) throw new IllegalArgumentException("Image format is not supported by the configured ImageIO readers");
            ImageReader reader = readers.next();
            try {
                reader.setInput(input, true, true);
                int width = reader.getWidth(0), height = reader.getHeight(0);
                if (width < 1 || height < 1 || width > 12000 || height > 12000 || (long)width * height > 20_000_000L)
                    throw new IllegalArgumentException("Image dimensions are too large");
                java.awt.image.BufferedImage image = reader.read(0);
                if (image == null) throw new IllegalArgumentException("Image could not be decoded");
                int max = 900;
                double scale = Math.min(1.0, (double) max / Math.max(image.getWidth(), image.getHeight()));
                java.awt.image.BufferedImage resized = new java.awt.image.BufferedImage(Math.max(1,(int)(image.getWidth()*scale)), Math.max(1,(int)(image.getHeight()*scale)), java.awt.image.BufferedImage.TYPE_INT_RGB);
            java.awt.Graphics2D graphics = resized.createGraphics();
            graphics.drawImage(image, 0, 0, resized.getWidth(), resized.getHeight(), null);
            graphics.dispose();
            String format = source.toString().toLowerCase().endsWith(".png") ? "png" : "jpg";
                if (!javax.imageio.ImageIO.write(resized, format, target.toFile())) throw new IllegalArgumentException("Image resize writer is unavailable");
            } finally { reader.dispose(); }
        } catch (IOException e) { throw new IllegalArgumentException("Image could not be decoded", e); }
    }
}
