package com.nestify.util;

import java.math.BigDecimal;
import java.util.regex.Pattern;

public final class ValidationUtil {
    private static final Pattern EMAIL = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    private static final Pattern MOBILE = Pattern.compile("^\\+?[0-9]{10,15}$");
    private ValidationUtil() {}
    public static String required(String value, String field, int max) {
        String clean = value == null ? "" : value.trim();
        if (clean.isEmpty() || clean.length() > max) throw new IllegalArgumentException(field + " is required and must be at most " + max + " characters");
        return clean;
    }
    public static String email(String value) {
        String clean = required(value, "Email", 190);
        if (!EMAIL.matcher(clean).matches()) throw new IllegalArgumentException("Enter a valid email address");
        return clean.toLowerCase(java.util.Locale.ROOT);
    }
    public static String mobile(String value) {
        String clean = required(value, "Mobile number", 16);
        if (!MOBILE.matcher(clean).matches()) throw new IllegalArgumentException("Enter a valid mobile number");
        return clean;
    }
    public static BigDecimal money(String value, String field) {
        try {
            BigDecimal amount = new BigDecimal(required(value, field, 14));
            if (amount.signum() < 0 || amount.scale() > 2 || amount.compareTo(new BigDecimal("99999999.99")) > 0)
                throw new IllegalArgumentException(field + " must be a non-negative amount with at most two decimals");
            return amount;
        } catch (NumberFormatException e) { throw new IllegalArgumentException(field + " must be a valid amount"); }
    }
    public static String enumValue(String value, String field, String... options) {
        String clean = required(value, field, 40).toUpperCase(java.util.Locale.ROOT);
        for (String option : options) if (option.equals(clean)) return clean;
        throw new IllegalArgumentException("Invalid " + field);
    }
}
