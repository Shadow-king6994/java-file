package com.nestify.util;

import java.security.SecureRandom;
import java.util.HexFormat;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public final class OtpUtil {
    private static final SecureRandom RANDOM = new SecureRandom();
    private OtpUtil() {}
    public static String generate() { return "%06d".formatted(RANDOM.nextInt(1_000_000)); }
    public static String hash(String otp) {
        try { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(otp.getBytes(java.nio.charset.StandardCharsets.UTF_8))); }
        catch (NoSuchAlgorithmException e) { throw new IllegalStateException("SHA-256 is unavailable", e); }
    }
    public static boolean matches(String otp, String hash) {
        if (otp == null || hash == null) return false;
        return MessageDigest.isEqual(hash(otp).getBytes(java.nio.charset.StandardCharsets.UTF_8), hash.getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }
}
