package com.nestify.util;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

public final class DbUtil {
    private static HikariDataSource dataSource;
    private static Properties properties;
    private DbUtil() {}

    public static synchronized void initialize() {
        if (dataSource != null) return;
        properties = new Properties();
        String configPath = System.getenv("NESTIFY_CONFIG");
        if (configPath != null && !configPath.isBlank()) {
            try (InputStream input = Files.newInputStream(Path.of(configPath))) {
                properties.load(input);
            } catch (Exception e) {
                throw new IllegalStateException("Unable to read NESTIFY_CONFIG file", e);
            }
        }
        String url = value("DB_URL", "db.url");
        String user = value("DB_USER", "db.user");
        String password = value("DB_PASSWORD", "db.password");
        if (url == null || user == null || password == null) {
            throw new IllegalStateException("Database settings are required in NESTIFY_CONFIG or DB_URL/DB_USER/DB_PASSWORD");
        }
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl(url);
        config.setDriverClassName("com.mysql.cj.jdbc.Driver");
        config.setUsername(user);
        config.setPassword(password);
        config.setMaximumPoolSize(12);
        config.setMinimumIdle(2);
        config.setPoolName("nestify-pool");
        config.setConnectionTimeout(10000);
        dataSource = new HikariDataSource(config);
    }

    private static String value(String environment, String property) {
        String env = System.getenv(environment);
        if (env != null && !env.isBlank()) return env;
        String configured = properties.getProperty(property);
        return configured == null || configured.isBlank() ? null : configured.trim();
    }
    public static Connection getConnection() throws SQLException {
        if (dataSource == null) initialize();
        return dataSource.getConnection();
    }
    public static String setting(String key) {
        return setting(key, null);
    }
    public static String setting(String key, String defaultValue) {
        if (properties == null) initialize();
        String environment = switch (key) {
            case "smtp.host" -> "SMTP_HOST";
            case "smtp.port" -> "SMTP_PORT";
            case "smtp.user" -> "SMTP_USER";
            case "smtp.password" -> "SMTP_PASSWORD";
            case "mail.from" -> "MAIL_FROM";
            case "upload.path" -> "UPLOAD_PATH";
            case "admin.email" -> "ADMIN_EMAIL";
            case "admin.password" -> "ADMIN_PASSWORD";
            default -> null;
        };
        if (environment != null) {
            String value = System.getenv(environment);
            if (value != null && !value.isBlank()) return value.trim();
        }
        return properties.getProperty(key, defaultValue);
    }
    public static synchronized void shutdown() {
        if (dataSource != null) { dataSource.close(); dataSource = null; }
    }
}
