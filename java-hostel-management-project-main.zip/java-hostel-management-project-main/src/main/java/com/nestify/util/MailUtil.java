package com.nestify.util;

import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import java.util.Properties;

public class MailUtil {
    public void send(String to, String subject, String body) throws Exception {
        Properties config = new Properties();
        String host = DbUtil.setting("smtp.host");
        String port = DbUtil.setting("smtp.port");
        String username = DbUtil.setting("smtp.user");
        String password = DbUtil.setting("smtp.password");
        boolean authenticate = Boolean.parseBoolean(DbUtil.setting("smtp.auth", "true"));
        if (host == null || (authenticate && (username == null || password == null))) throw new IllegalStateException("SMTP is not configured");
        config.put("mail.smtp.auth", Boolean.toString(authenticate));
        config.put("mail.smtp.starttls.enable", DbUtil.setting("smtp.starttls", "true"));
        config.put("mail.smtp.host", host);
        config.put("mail.smtp.port", port == null ? "587" : port);
        Session session = Session.getInstance(config, new Authenticator() {
            @Override protected PasswordAuthentication getPasswordAuthentication() { return new PasswordAuthentication(username, password); }
        });
        MimeMessage message = new MimeMessage(session);
        message.setFrom(new InternetAddress(DbUtil.setting("mail.from") == null ? username : DbUtil.setting("mail.from")));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
        message.setSubject(subject, "UTF-8");
        message.setText(body, "UTF-8");
        Transport.send(message);
    }
}
