package com.nestify.dao;
import com.nestify.model.User;
import java.util.Optional;
import java.util.List;
public interface UserDao {
    Optional<User> findByEmail(String email);
    Optional<User> findById(long id);
    long create(User user);
    void markVerified(long userId);
    void recordLoginFailure(long userId);
    void resetLoginFailures(long userId);
    boolean loginAllowed(long userId);
    void saveOtp(long userId, String hash);
    boolean consumeOtp(long userId, String hash);
    List<User> findAll();
    void setStatus(long userId,String status);
    void updateProfile(long userId,String name,String mobile);
}
