package com.nestify.dao.impl;
import com.nestify.dao.NotificationDao;
import com.nestify.model.Notification;
import com.nestify.util.DbUtil;
import java.sql.*;
import java.util.*;
public class NotificationDaoImpl implements NotificationDao {
    @Override public void create(long id,String subject,String body){try(Connection c=DbUtil.getConnection();PreparedStatement p=c.prepareStatement("INSERT INTO notifications(user_id,subject,body) VALUES(?,?,?)")){p.setLong(1,id);p.setString(2,subject);p.setString(3,body);p.executeUpdate();}catch(SQLException e){throw new IllegalStateException("Notification could not be saved",e);}}
    @Override public List<Notification> findForUser(long id){List<Notification> out=new ArrayList<>();try(Connection c=DbUtil.getConnection();PreparedStatement p=c.prepareStatement("SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50")){p.setLong(1,id);try(ResultSet r=p.executeQuery()){while(r.next()){Notification n=new Notification();n.setId(r.getLong("id"));n.setUserId(id);n.setSubject(r.getString("subject"));n.setBody(r.getString("body"));n.setRead(r.getBoolean("is_read"));out.add(n);}}return out;}catch(SQLException e){throw new IllegalStateException("Could not load notifications",e);}}
}
