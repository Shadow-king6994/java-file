package com.nestify.dao.impl;
import com.nestify.dao.FavouriteDao;
import com.nestify.dao.PropertyDao;
import com.nestify.model.Property;
import com.nestify.util.DbUtil;
import java.sql.*;
import java.util.*;
public class FavouriteDaoImpl implements FavouriteDao {
    private final PropertyDao properties;
    public FavouriteDaoImpl(PropertyDao properties){this.properties=properties;}
    @Override public void toggle(long user,long property){
        try(Connection c=DbUtil.getConnection()){
            try(PreparedStatement d=c.prepareStatement("DELETE FROM favourites WHERE user_id=? AND property_id=?")){d.setLong(1,user);d.setLong(2,property);if(d.executeUpdate()==1)return;}
            try(PreparedStatement p=c.prepareStatement("INSERT INTO favourites(user_id,property_id) SELECT ?,id FROM properties WHERE id=? AND status='APPROVED'")){p.setLong(1,user);p.setLong(2,property);if(p.executeUpdate()!=1)throw new IllegalArgumentException("Listing is unavailable");}
        }catch(SQLException e){throw new IllegalStateException("Favourite could not be updated",e);}
    }
    @Override public boolean contains(long user,long property){try(Connection c=DbUtil.getConnection();PreparedStatement p=c.prepareStatement("SELECT 1 FROM favourites WHERE user_id=? AND property_id=?")){p.setLong(1,user);p.setLong(2,property);try(ResultSet r=p.executeQuery()){return r.next();}}catch(SQLException e){throw new IllegalStateException("Favourite lookup failed",e);}}
    @Override public List<Property> findForUser(long user){
        List<Property> out=new ArrayList<>();
        try(Connection c=DbUtil.getConnection();PreparedStatement p=c.prepareStatement("SELECT property_id FROM favourites WHERE user_id=? ORDER BY created_at DESC")){p.setLong(1,user);try(ResultSet r=p.executeQuery()){while(r.next())properties.findPublicById(r.getLong(1)).ifPresent(out::add);}return out;}catch(SQLException e){throw new IllegalStateException("Could not load favourites",e);}
    }
}
