package com.nestify.dao;
import com.nestify.model.Report;
import java.util.List;
public interface ReportDao { long create(Report report); List<Report> findOpen(); void setStatus(long reportId,String status); }
