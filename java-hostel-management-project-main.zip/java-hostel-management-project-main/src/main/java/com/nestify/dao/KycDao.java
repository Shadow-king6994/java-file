package com.nestify.dao;
import com.nestify.model.OwnerKyc;
import java.util.List;
import java.util.Optional;
public interface KycDao {
    void save(OwnerKyc kyc);
    Optional<OwnerKyc> findByOwner(long ownerId);
    List<OwnerKyc> pending();
    void review(long id, long adminId, String status, String reason);
}
