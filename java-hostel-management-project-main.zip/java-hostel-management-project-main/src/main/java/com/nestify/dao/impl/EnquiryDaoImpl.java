package com.nestify.dao.impl;
import com.nestify.dao.EnquiryDao;
import com.nestify.model.Enquiry;
import com.nestify.util.DbUtil;
import java.sql.*;
import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EnquiryDaoImpl implements EnquiryDao {
    private static final Logger LOG=LoggerFactory.getLogger(EnquiryDaoImpl.class);
    @Override public long create(Enquiry e){
        String sql="INSERT INTO enquiries(property_id,tenant_id,name,mobile,email,gender,occupation,college_company,move_in_date,stay_duration,room_interest,budget,message,preferred_visit_date,preferred_visit_slot) SELECT ?,?,?,?,?,?,?,?,?,?,?,?,?,?,? FROM properties WHERE id=? AND status='APPROVED'";
        try(Connection c=DbUtil.getConnection();PreparedStatement p=c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)){
            p.setLong(1,e.getPropertyId());if(e.getTenantId()>0)p.setLong(2,e.getTenantId());else p.setNull(2,Types.BIGINT);
            p.setString(3,e.getName());p.setString(4,e.getMobile());p.setString(5,e.getEmail());p.setString(6,e.getGender());p.setString(7,e.getOccupation());
            p.setString(8,e.getCollegeCompany());p.setDate(9,e.getMoveInDate());p.setString(10,e.getStayDuration());p.setString(11,e.getRoomInterest());
            p.setBigDecimal(12,e.getBudget());p.setString(13,e.getMessage());p.setDate(14,e.getPreferredVisitDate());p.setString(15,e.getPreferredVisitSlot());p.setLong(16,e.getPropertyId());if(p.executeUpdate()!=1)throw new IllegalArgumentException("Listing is no longer available");
            try(ResultSet r=p.getGeneratedKeys()){if(!r.next())throw new SQLException("Enquiry insert returned no key");return r.getLong(1);}
        }catch(SQLException ex){LOG.error("Enquiry create failed",ex);throw new IllegalStateException("Enquiry could not be sent",ex);}
    }
    @Override public List<Enquiry> findForOwner(long ownerId){return query("SELECT e.* FROM enquiries e JOIN properties p ON p.id=e.property_id WHERE p.owner_id=? ORDER BY e.created_at DESC",ownerId);}
    @Override public List<Enquiry> findForTenant(long id){return query("SELECT * FROM enquiries WHERE tenant_id=? ORDER BY created_at DESC",id);}
    @Override public void setOwnerStatus(long owner,long enquiry,String status){
        try(Connection c=DbUtil.getConnection();PreparedStatement p=c.prepareStatement("UPDATE enquiries e JOIN properties pr ON pr.id=e.property_id SET e.status=? WHERE e.id=? AND pr.owner_id=?")){p.setString(1,status);p.setLong(2,enquiry);p.setLong(3,owner);if(p.executeUpdate()!=1)throw new IllegalArgumentException("Enquiry not found");}
        catch(SQLException e){LOG.error("Enquiry update failed",e);throw new IllegalStateException("Enquiry update failed",e);}
    }
    private List<Enquiry> query(String sql,long id){
        List<Enquiry> out=new ArrayList<>();
        try(Connection c=DbUtil.getConnection();PreparedStatement p=c.prepareStatement(sql)){p.setLong(1,id);try(ResultSet r=p.executeQuery()){while(r.next()){
            Enquiry e=new Enquiry();e.setId(r.getLong("id"));e.setPropertyId(r.getLong("property_id"));e.setTenantId(r.getLong("tenant_id"));e.setName(r.getString("name"));e.setMobile(r.getString("mobile"));e.setEmail(r.getString("email"));e.setGender(r.getString("gender"));e.setOccupation(r.getString("occupation"));e.setCollegeCompany(r.getString("college_company"));e.setMoveInDate(r.getDate("move_in_date"));e.setStayDuration(r.getString("stay_duration"));e.setRoomInterest(r.getString("room_interest"));e.setBudget(r.getBigDecimal("budget"));e.setMessage(r.getString("message"));e.setPreferredVisitDate(r.getDate("preferred_visit_date"));e.setPreferredVisitSlot(r.getString("preferred_visit_slot"));e.setStatus(r.getString("status"));e.setCreatedAt(r.getTimestamp("created_at"));out.add(e);
        }}return out;}catch(SQLException ex){LOG.error("Enquiry query failed",ex);throw new IllegalStateException("Could not load enquiries",ex);}
    }
}
