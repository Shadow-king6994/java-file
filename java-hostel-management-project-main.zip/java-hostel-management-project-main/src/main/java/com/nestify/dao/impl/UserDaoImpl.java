package com.nestify.dao.impl;

import com.nestify.dao.UserDao;
import com.nestify.model.User;
import com.nestify.util.DbUtil;
import com.nestify.util.ConnectionProvider;
import java.sql.*;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UserDaoImpl implements UserDao {
    private static final Logger LOG=LoggerFactory.getLogger(UserDaoImpl.class);
    private final ConnectionProvider connections;
    public UserDaoImpl(){this(DbUtil::getConnection);}
    public UserDaoImpl(ConnectionProvider connections){this.connections=connections;}
    private User map(ResultSet r)throws SQLException{User u=new User(r.getLong("id"),r.getString("name"),r.getString("mobile"),r.getString("email"),r.getString("password_hash"),r.getString("role"),r.getBoolean("email_verified"));u.setStatus(r.getString("status"));return u;}
    @Override public Optional<User> findByEmail(String email){
        try(Connection c=connections.get();PreparedStatement p=c.prepareStatement("SELECT * FROM users WHERE email=?")){
            p.setString(1,email);try(ResultSet r=p.executeQuery()){return r.next()?Optional.of(map(r)):Optional.empty();}
        }catch(SQLException e){LOG.error("Could not find user by email",e);throw new IllegalStateException("User lookup failed",e);}
    }
    @Override public Optional<User> findById(long id){
        try(Connection c=connections.get();PreparedStatement p=c.prepareStatement("SELECT * FROM users WHERE id=?")){
            p.setLong(1,id);try(ResultSet r=p.executeQuery()){return r.next()?Optional.of(map(r)):Optional.empty();}
        }catch(SQLException e){LOG.error("Could not find user",e);throw new IllegalStateException("User lookup failed",e);}
    }
    @Override public long create(User u){
        try(Connection c=connections.get();PreparedStatement p=c.prepareStatement("INSERT INTO users(name,mobile,email,password_hash,role) VALUES(?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS)){
            p.setString(1,u.getName());p.setString(2,u.getMobile());p.setString(3,u.getEmail());p.setString(4,u.getPasswordHash());p.setString(5,u.getRole());p.executeUpdate();
            try(ResultSet r=p.getGeneratedKeys()){if(!r.next())throw new SQLException("User insert returned no key");return r.getLong(1);}
        }catch(SQLException e){LOG.error("Could not create user",e);throw new IllegalStateException("Account creation failed",e);}
    }
    @Override public void markVerified(long id){update("UPDATE users SET email_verified=TRUE WHERE id=?",id);}
    @Override public void recordLoginFailure(long id){
        try(Connection c=connections.get();PreparedStatement p=c.prepareStatement("UPDATE users SET status=IF(failed_logins>=4,'LOCKED',status),lock_until=IF(failed_logins>=4,DATE_ADD(NOW(),INTERVAL 15 MINUTE),lock_until),failed_logins=failed_logins+1 WHERE id=?")){p.setLong(1,id);p.executeUpdate();}
        catch(SQLException e){LOG.error("Could not record failed login",e);throw new IllegalStateException("Login update failed",e);}
    }
    @Override public void resetLoginFailures(long id){
        try(Connection c=connections.get();PreparedStatement p=c.prepareStatement("UPDATE users SET failed_logins=0,status='ACTIVE',lock_until=NULL WHERE id=?")){p.setLong(1,id);p.executeUpdate();}
        catch(SQLException e){LOG.error("Could not reset failed login count",e);throw new IllegalStateException("Login update failed",e);}
    }
    @Override public boolean loginAllowed(long id){
        try(Connection c=connections.get()){
            try(PreparedStatement p=c.prepareStatement("UPDATE users SET failed_logins=0,status='ACTIVE',lock_until=NULL WHERE id=? AND status='LOCKED' AND lock_until<=NOW()")){p.setLong(1,id);p.executeUpdate();}
            try(PreparedStatement p=c.prepareStatement("SELECT status FROM users WHERE id=?")){p.setLong(1,id);try(ResultSet r=p.executeQuery()){return r.next()&&"ACTIVE".equals(r.getString(1));}}
        }catch(SQLException e){LOG.error("Could not check login state",e);throw new IllegalStateException("Login check failed",e);}
    }
    private void update(String sql,long id){try(Connection c=connections.get();PreparedStatement p=c.prepareStatement(sql)){p.setLong(1,id);p.executeUpdate();}catch(SQLException e){LOG.error("Could not update user",e);throw new IllegalStateException("User update failed",e);}}
    @Override public void saveOtp(long id,String hash){
        try(Connection c=connections.get()){
            try(PreparedStatement p=c.prepareStatement("UPDATE otp_tokens SET consumed_at=NOW() WHERE user_id=? AND consumed_at IS NULL")){p.setLong(1,id);p.executeUpdate();}
            try(PreparedStatement p=c.prepareStatement("INSERT INTO otp_tokens(user_id,token_hash,expires_at) VALUES(?,?,DATE_ADD(NOW(),INTERVAL 10 MINUTE))")){p.setLong(1,id);p.setString(2,hash);p.executeUpdate();}
        }catch(SQLException e){LOG.error("Could not store OTP",e);throw new IllegalStateException("OTP request failed",e);}
    }
    @Override public boolean consumeOtp(long id,String hash){
        try(Connection c=connections.get();PreparedStatement p=c.prepareStatement("UPDATE otp_tokens SET consumed_at=NOW() WHERE user_id=? AND token_hash=? AND consumed_at IS NULL AND expires_at>NOW()")){
            p.setLong(1,id);p.setString(2,hash);return p.executeUpdate()==1;
        }catch(SQLException e){LOG.error("Could not verify OTP",e);throw new IllegalStateException("OTP verification failed",e);}
    }
    @Override public java.util.List<User> findAll(){
        java.util.List<User> result=new java.util.ArrayList<>();
        try(Connection c=connections.get();PreparedStatement p=c.prepareStatement("SELECT * FROM users ORDER BY created_at DESC LIMIT 250");ResultSet r=p.executeQuery()){while(r.next())result.add(map(r));return result;}
        catch(SQLException e){LOG.error("Could not list users",e);throw new IllegalStateException("User list failed",e);}
    }
    @Override public void setStatus(long id,String status){
        try(Connection c=connections.get();PreparedStatement p=c.prepareStatement("UPDATE users SET status=?,failed_logins=0,lock_until=NULL WHERE id=?")){p.setString(1,status);p.setLong(2,id);if(p.executeUpdate()!=1)throw new IllegalArgumentException("User not found");}
        catch(SQLException e){LOG.error("Could not change user status",e);throw new IllegalStateException("User update failed",e);}
    }
    @Override public void updateProfile(long id,String name,String mobile){
        try(Connection c=connections.get();PreparedStatement p=c.prepareStatement("UPDATE users SET name=?,mobile=? WHERE id=?")){p.setString(1,name);p.setString(2,mobile);p.setLong(3,id);if(p.executeUpdate()!=1)throw new IllegalArgumentException("Account not found");}
        catch(SQLException e){LOG.error("Could not update profile",e);throw new IllegalStateException("Profile update failed",e);}
    }
}
