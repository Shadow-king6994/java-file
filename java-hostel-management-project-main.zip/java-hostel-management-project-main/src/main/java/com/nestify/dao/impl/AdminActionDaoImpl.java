package com.nestify.dao.impl;
import com.nestify.dao.AdminActionDao;
import com.nestify.model.AdminAction;
import com.nestify.util.DbUtil;
import java.sql.*;
import java.util.*;
public class AdminActionDaoImpl implements AdminActionDao {
    @Override public void create(AdminAction a){try(Connection c=DbUtil.getConnection();PreparedStatement p=c.prepareStatement("INSERT INTO admin_actions(admin_id,target_type,target_id,action,reason) VALUES(?,?,?,?,?)")){p.setLong(1,a.getAdminId());p.setString(2,a.getTargetType());p.setLong(3,a.getTargetId());p.setString(4,a.getAction());p.setString(5,a.getReason());p.executeUpdate();}catch(SQLException e){throw new IllegalStateException("Audit action failed",e);}}
    @Override public List<AdminAction> recent(int limit){List<AdminAction> out=new ArrayList<>();try(Connection c=DbUtil.getConnection();PreparedStatement p=c.prepareStatement("SELECT * FROM admin_actions ORDER BY created_at DESC LIMIT ?")){p.setInt(1,Math.min(Math.max(limit,1),200));try(ResultSet r=p.executeQuery()){while(r.next()){AdminAction a=new AdminAction();a.setId(r.getLong("id"));a.setAdminId(r.getLong("admin_id"));a.setTargetType(r.getString("target_type"));a.setTargetId(r.getLong("target_id"));a.setAction(r.getString("action"));a.setReason(r.getString("reason"));out.add(a);}}return out;}catch(SQLException e){throw new IllegalStateException("Audit log query failed",e);}}
}
