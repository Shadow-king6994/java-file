package com.nestify.dao.impl;
import com.nestify.dao.KycDao;
import com.nestify.model.OwnerKyc;
import com.nestify.util.DbUtil;
import java.sql.*;
import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class KycDaoImpl implements KycDao {
    private static final Logger LOG=LoggerFactory.getLogger(KycDaoImpl.class);
    private OwnerKyc map(ResultSet r)throws SQLException{OwnerKyc k=new OwnerKyc();k.setId(r.getLong("id"));k.setUserId(r.getLong("user_id"));k.setIdType(r.getString("id_type"));k.setIdNumber(r.getString("id_number"));k.setIdFrontPath(r.getString("id_front_path"));k.setIdBackPath(r.getString("id_back_path"));k.setSelfiePath(r.getString("selfie_path"));k.setOwnershipProofPath(r.getString("ownership_proof_path"));k.setStatus(r.getString("status"));k.setReviewReason(r.getString("review_reason"));return k;}
    @Override public void save(OwnerKyc k){
        String sql="INSERT INTO owner_kyc(user_id,id_type,id_number,id_front_path,id_back_path,selfie_path,ownership_proof_path,status) VALUES(?,?,?,?,?,?,?,'PENDING') ON DUPLICATE KEY UPDATE id_type=VALUES(id_type),id_number=VALUES(id_number),id_front_path=VALUES(id_front_path),id_back_path=VALUES(id_back_path),selfie_path=VALUES(selfie_path),ownership_proof_path=VALUES(ownership_proof_path),status='PENDING',review_reason=NULL";
        try(Connection c=DbUtil.getConnection();PreparedStatement p=c.prepareStatement(sql)){p.setLong(1,k.getUserId());p.setString(2,k.getIdType());p.setString(3,k.getIdNumber());p.setString(4,k.getIdFrontPath());p.setString(5,k.getIdBackPath());p.setString(6,k.getSelfiePath());p.setString(7,k.getOwnershipProofPath());p.executeUpdate();}
        catch(SQLException e){LOG.error("KYC save failed",e);throw new IllegalStateException("Verification submission failed",e);}
    }
    @Override public Optional<OwnerKyc> findByOwner(long id){return one("SELECT * FROM owner_kyc WHERE user_id=?",id);}
    @Override public List<OwnerKyc> pending(){List<OwnerKyc> all=new ArrayList<>();try(Connection c=DbUtil.getConnection();PreparedStatement p=c.prepareStatement("SELECT * FROM owner_kyc WHERE status IN ('PENDING','NEEDS_MORE_INFO') ORDER BY created_at")){try(ResultSet r=p.executeQuery()){while(r.next())all.add(map(r));}return all;}catch(SQLException e){LOG.error("KYC queue query failed",e);throw new IllegalStateException("Could not load verification queue",e);}}
    private Optional<OwnerKyc> one(String sql,long id){try(Connection c=DbUtil.getConnection();PreparedStatement p=c.prepareStatement(sql)){p.setLong(1,id);try(ResultSet r=p.executeQuery()){return r.next()?Optional.of(map(r)):Optional.empty();}}catch(SQLException e){LOG.error("KYC query failed",e);throw new IllegalStateException("Could not load verification",e);}}
    @Override public void review(long id,long admin,String status,String reason){
        try(Connection c=DbUtil.getConnection()){
            c.setAutoCommit(false);
            try(PreparedStatement p=c.prepareStatement("UPDATE owner_kyc SET status=?,review_reason=?,reviewed_by=?,reviewed_at=NOW() WHERE id=?")){p.setString(1,status);p.setString(2,reason);p.setLong(3,admin);p.setLong(4,id);if(p.executeUpdate()!=1)throw new IllegalArgumentException("KYC record not found");}
            try(PreparedStatement p=c.prepareStatement("INSERT INTO admin_actions(admin_id,target_type,target_id,action,reason) VALUES(?,'KYC',?,?,?)")){p.setLong(1,admin);p.setLong(2,id);p.setString(3,status);p.setString(4,reason);p.executeUpdate();}
            c.commit();
        }catch(Exception e){LOG.error("KYC review failed",e);throw new IllegalStateException("Verification review failed",e);}
    }
}
