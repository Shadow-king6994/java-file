package com.nestify.dao;
import com.nestify.model.Notification;
import java.util.List;
public interface NotificationDao { void create(long userId,String subject,String body); List<Notification> findForUser(long userId); }
