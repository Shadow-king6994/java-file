package com.nestify.dao;
import com.nestify.model.Property;
import java.util.List;
import java.util.Optional;
import java.util.Map;
public interface PropertyDao {
    List<Property> search(Map<String,String> filters, int page, int pageSize);
    List<Property> featured(int limit);
    Optional<Property> findPublicById(long id);
    Optional<Property> findById(long id);
    List<Property> findByOwner(long ownerId);
    List<Property> pending();
    long create(Property property);
    void update(Property property);
    void setStatus(long propertyId, String status, long adminId, String reason);
}
