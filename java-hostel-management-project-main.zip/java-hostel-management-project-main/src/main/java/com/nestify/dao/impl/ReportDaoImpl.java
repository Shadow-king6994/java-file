package com.nestify.dao.impl;
import com.nestify.dao.ReportDao;
import com.nestify.model.Report;
import com.nestify.util.DbUtil;
import java.sql.*;
import java.util.*;
public class ReportDaoImpl implements ReportDao {
    @Override public long create(Report r){try(Connection c=DbUtil.getConnection();PreparedStatement p=c.prepareStatement("INSERT INTO reports(property_id,reporter_id,reason,details) SELECT ?,?,?,? FROM properties WHERE id=? AND status='APPROVED'",Statement.RETURN_GENERATED_KEYS)){p.setLong(1,r.getPropertyId());if(r.getReporterId()>0)p.setLong(2,r.getReporterId());else p.setNull(2,Types.BIGINT);p.setString(3,r.getReason());p.setString(4,r.getDetails());p.setLong(5,r.getPropertyId());if(p.executeUpdate()!=1)throw new IllegalArgumentException("Listing is unavailable");try(ResultSet rs=p.getGeneratedKeys()){if(!rs.next())throw new SQLException("Report insert returned no key");return rs.getLong(1);}}catch(SQLException e){throw new IllegalStateException("Report could not be submitted",e);}}
    @Override public List<Report> findOpen(){List<Report> out=new ArrayList<>();try(Connection c=DbUtil.getConnection();PreparedStatement p=c.prepareStatement("SELECT * FROM reports WHERE status='OPEN' ORDER BY created_at DESC");ResultSet r=p.executeQuery()){while(r.next()){Report x=new Report();x.setId(r.getLong("id"));x.setPropertyId(r.getLong("property_id"));x.setReporterId(r.getLong("reporter_id"));x.setReason(r.getString("reason"));x.setDetails(r.getString("details"));x.setStatus(r.getString("status"));out.add(x);}return out;}catch(SQLException e){throw new IllegalStateException("Could not load reports",e);}}
    @Override public void setStatus(long id,String status){try(Connection c=DbUtil.getConnection();PreparedStatement p=c.prepareStatement("UPDATE reports SET status=? WHERE id=?")){p.setString(1,status);p.setLong(2,id);if(p.executeUpdate()!=1)throw new IllegalArgumentException("Report not found");}catch(SQLException e){throw new IllegalStateException("Report update failed",e);}}
}
