package com.nestify.dao;
import com.nestify.model.Enquiry;
import java.util.List;
public interface EnquiryDao {
    long create(Enquiry enquiry);
    List<Enquiry> findForOwner(long ownerId);
    List<Enquiry> findForTenant(long tenantId);
    void setOwnerStatus(long ownerId,long enquiryId,String status);
}
