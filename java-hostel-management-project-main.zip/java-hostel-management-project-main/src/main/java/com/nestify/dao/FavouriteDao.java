package com.nestify.dao;
import com.nestify.model.Property;
import java.util.List;
public interface FavouriteDao {
    void toggle(long userId,long propertyId);
    boolean contains(long userId,long propertyId);
    List<Property> findForUser(long userId);
}
