package com.nestify.dao;
import com.nestify.model.AdminAction;
import java.util.List;
public interface AdminActionDao { void create(AdminAction action); List<AdminAction> recent(int limit); }
