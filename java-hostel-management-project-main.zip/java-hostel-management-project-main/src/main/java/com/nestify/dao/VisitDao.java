package com.nestify.dao;
import com.nestify.model.Visit;
import java.util.List;
public interface VisitDao {
    long create(Visit visit);
    List<Visit> findForTenant(long tenantId);
    List<Visit> findForOwner(long ownerId);
    void setOwnerStatus(long ownerId,long visitId,String status);
}
