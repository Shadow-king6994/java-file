package com.nestify.dao.impl;

import com.nestify.dao.PropertyDao;
import com.nestify.model.Photo;
import com.nestify.model.Property;
import com.nestify.model.RoomType;
import com.nestify.util.ConnectionProvider;
import com.nestify.util.DbUtil;
import java.sql.*;
import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PropertyDaoImpl implements PropertyDao {
    private static final Logger LOG=LoggerFactory.getLogger(PropertyDaoImpl.class);
    private final ConnectionProvider connections;
    public PropertyDaoImpl(){this(DbUtil::getConnection);}
    public PropertyDaoImpl(ConnectionProvider connections){this.connections=connections;}

    private String base(){
        return "SELECT p.*,u.name owner_name,u.mobile owner_mobile,COALESCE(k.status='APPROVED',FALSE) verified_owner,COALESCE(MIN(rt.rent),0) starting_rent " +
            "FROM properties p JOIN users u ON u.id=p.owner_id LEFT JOIN owner_kyc k ON k.user_id=u.id " +
            "LEFT JOIN room_types rt ON rt.property_id=p.id ";
    }
    private Property map(ResultSet r)throws SQLException{
        Property p=new Property();p.setId(r.getLong("id"));p.setOwnerId(r.getLong("owner_id"));p.setTitle(r.getString("title"));
        p.setOwnerName(r.getString("owner_name"));p.setOwnerMobile(r.getString("owner_mobile"));
        p.setPropertyType(r.getString("property_type"));p.setSuitableFor(r.getString("suitable_for"));p.setCity(r.getString("city"));
        p.setLocality(r.getString("locality"));p.setFullAddress(r.getString("full_address"));p.setPincode(r.getString("pincode"));
        p.setTotalRooms(r.getInt("total_rooms"));p.setAvailableFrom(r.getDate("available_from"));p.setFoodOption(r.getString("food_option"));
        p.setMealDetails(r.getString("meal_details"));p.setCurfew(r.getString("curfew"));p.setVisitorRules(r.getString("visitor_rules"));
        p.setSmokingAllowed(r.getBoolean("smoking_allowed"));p.setAlcoholAllowed(r.getBoolean("alcohol_allowed"));p.setPetsAllowed(r.getBoolean("pets_allowed"));
        p.setNoticePeriod(r.getString("notice_period"));p.setMaintenanceCharges(r.getBigDecimal("maintenance_charges"));p.setDescription(r.getString("description"));
        p.setNearbyLandmarks(r.getString("nearby_landmarks"));p.setStatus(r.getString("status"));p.setReviewReason(r.getString("review_reason"));
        p.setVerifiedOwner(r.getBoolean("verified_owner"));p.setStartingRent(r.getBigDecimal("starting_rent"));return p;
    }
    @Override public List<Property> search(Map<String,String> filters,int page,int size){
        StringBuilder sql=new StringBuilder(base()).append("WHERE p.status='APPROVED' ");List<Object> args=new ArrayList<>();
        add(sql,args,"p.city",filters.get("city"));add(sql,args,"p.locality",filters.get("locality"));
        add(sql,args,"p.property_type",filters.get("type"));add(sql,args,"p.suitable_for",filters.get("gender"));
        if(filters.get("minPrice")!=null&&!filters.get("minPrice").isBlank()){sql.append("AND rt.rent>=? ");args.add(new java.math.BigDecimal(filters.get("minPrice")));}
        if(filters.get("maxPrice")!=null&&!filters.get("maxPrice").isBlank()){sql.append("AND rt.rent<=? ");args.add(new java.math.BigDecimal(filters.get("maxPrice")));}
        if(filters.get("food")!=null&&!filters.get("food").isBlank()){sql.append("AND p.food_option=? ");args.add(filters.get("food"));}
        if(filters.containsKey("verified"))sql.append("AND k.status='APPROVED' ");
        add(sql,args,"rt.sharing",filters.get("sharing"));
        if(filters.get("amenity")!=null&&!filters.get("amenity").isBlank()){
            sql.append("AND EXISTS (SELECT 1 FROM property_amenities pa JOIN amenities a ON a.id=pa.amenity_id WHERE pa.property_id=p.id AND UPPER(a.name)=?) ");
            args.add(filters.get("amenity"));
        }
        sql.append("GROUP BY p.id ORDER BY ").append("RENT".equals(filters.get("sort"))?"starting_rent ASC":"p.created_at DESC").append(" LIMIT ? OFFSET ?");
        args.add(size);args.add((page-1)*size);
        return query(sql.toString(),args);
    }
    private void add(StringBuilder sql,List<Object> args,String column,String value){
        if(value!=null&&!value.isBlank()){sql.append("AND ").append(column).append("=? ");args.add(value.trim());}
    }
    @Override public List<Property> featured(int limit){return query(base()+"WHERE p.status='APPROVED' GROUP BY p.id ORDER BY p.created_at DESC LIMIT ?",List.of(Math.min(Math.max(limit,1),24)));}
    @Override public Optional<Property> findPublicById(long id){return findOne(base()+"WHERE p.status='APPROVED' AND p.id=? GROUP BY p.id",id);}
    @Override public Optional<Property> findById(long id){return findOne(base()+"WHERE p.id=? GROUP BY p.id",id);}
    private Optional<Property> findOne(String sql,long id){return query(sql,List.of(id)).stream().findFirst();}
    @Override public List<Property> findByOwner(long ownerId){return query(base()+"WHERE p.owner_id=? GROUP BY p.id ORDER BY p.created_at DESC",List.of(ownerId));}
    @Override public List<Property> pending(){return query(base()+"WHERE p.status IN ('PENDING','NEEDS_MORE_INFO') GROUP BY p.id ORDER BY p.created_at",List.of());}
    private List<Property> query(String sql,List<?> args){
        List<Property> items=new ArrayList<>();
        try(Connection c=connections.get();PreparedStatement p=c.prepareStatement(sql)){
            for(int i=0;i<args.size();i++)p.setObject(i+1,args.get(i));
            try(ResultSet r=p.executeQuery()){while(r.next())items.add(map(r));}
            for(Property item:items)loadDetails(item);
            return items;
        }catch(SQLException e){LOG.error("Property query failed",e);throw new IllegalStateException("Listing search failed",e);}
    }
    private void loadDetails(Property item)throws SQLException{
        try(Connection c=connections.get()){
            try(PreparedStatement p=c.prepareStatement("SELECT * FROM room_types WHERE property_id=? ORDER BY rent")){
                p.setLong(1,item.getId());try(ResultSet r=p.executeQuery()){while(r.next()){
                    RoomType room=new RoomType();room.setId(r.getLong("id"));room.setPropertyId(item.getId());room.setSharing(r.getString("sharing"));
                    room.setRent(r.getBigDecimal("rent"));room.setDeposit(r.getBigDecimal("deposit"));room.setAvailableCount(r.getInt("available_count"));item.getRoomTypes().add(room);
                }}
            }
            try(PreparedStatement p=c.prepareStatement("SELECT * FROM property_photos WHERE property_id=? ORDER BY is_cover DESC,sort_order")){
                p.setLong(1,item.getId());try(ResultSet r=p.executeQuery()){while(r.next()){
                    Photo photo=new Photo();photo.setId(r.getLong("id"));photo.setPropertyId(item.getId());photo.setFilePath(r.getString("file_path"));
                    photo.setCover(r.getBoolean("is_cover"));photo.setSortOrder(r.getInt("sort_order"));item.getPhotos().add(photo);
                }}
            }
            try(PreparedStatement p=c.prepareStatement("SELECT a.name FROM amenities a JOIN property_amenities pa ON pa.amenity_id=a.id WHERE pa.property_id=?")){
                p.setLong(1,item.getId());try(ResultSet r=p.executeQuery()){while(r.next())item.getAmenities().add(r.getString(1));}
            }
        }
    }
    @Override public long create(Property property){
        String sql="INSERT INTO properties(owner_id,title,property_type,suitable_for,city,locality,full_address,pincode,total_rooms,available_from,food_option,meal_details,curfew,visitor_rules,smoking_allowed,alcohol_allowed,pets_allowed,notice_period,maintenance_charges,description,nearby_landmarks,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'PENDING')";
        try(Connection c=connections.get()){
            c.setAutoCommit(false);
            try(PreparedStatement s=c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)){
                int i=1;s.setLong(i++,property.getOwnerId());s.setString(i++,property.getTitle());s.setString(i++,property.getPropertyType());s.setString(i++,property.getSuitableFor());
                s.setString(i++,property.getCity());s.setString(i++,property.getLocality());s.setString(i++,property.getFullAddress());s.setString(i++,property.getPincode());
                s.setInt(i++,property.getTotalRooms());s.setDate(i++,property.getAvailableFrom());s.setString(i++,property.getFoodOption());s.setString(i++,property.getMealDetails());
                s.setString(i++,property.getCurfew());s.setString(i++,property.getVisitorRules());s.setBoolean(i++,property.isSmokingAllowed());s.setBoolean(i++,property.isAlcoholAllowed());
                s.setBoolean(i++,property.isPetsAllowed());s.setString(i++,property.getNoticePeriod());s.setBigDecimal(i++,property.getMaintenanceCharges());
                s.setString(i++,property.getDescription());s.setString(i,property.getNearbyLandmarks());s.executeUpdate();
                try(ResultSet keys=s.getGeneratedKeys()){
                    if(!keys.next())throw new SQLException("Listing insert returned no key");
                    long id=keys.getLong(1);writeChildren(c,id,property);c.commit();return id;
                }
            }catch(Exception e){c.rollback();throw e;}
        }catch(Exception e){LOG.error("Listing creation failed",e);throw new IllegalStateException("Listing could not be saved",e);}
    }
    @Override public void update(Property property){
        String sql="UPDATE properties SET title=?,property_type=?,suitable_for=?,city=?,locality=?,full_address=?,pincode=?,total_rooms=?,available_from=?,food_option=?,meal_details=?,curfew=?,visitor_rules=?,smoking_allowed=?,alcohol_allowed=?,pets_allowed=?,notice_period=?,maintenance_charges=?,description=?,nearby_landmarks=?,status='PENDING',review_reason=NULL,reviewed_by=NULL,reviewed_at=NULL WHERE id=? AND owner_id=?";
        try(Connection c=connections.get()){
            c.setAutoCommit(false);
            try(PreparedStatement s=c.prepareStatement(sql)){
                int i=1;s.setString(i++,property.getTitle());s.setString(i++,property.getPropertyType());s.setString(i++,property.getSuitableFor());s.setString(i++,property.getCity());
                s.setString(i++,property.getLocality());s.setString(i++,property.getFullAddress());s.setString(i++,property.getPincode());s.setInt(i++,property.getTotalRooms());
                s.setDate(i++,property.getAvailableFrom());s.setString(i++,property.getFoodOption());s.setString(i++,property.getMealDetails());s.setString(i++,property.getCurfew());
                s.setString(i++,property.getVisitorRules());s.setBoolean(i++,property.isSmokingAllowed());s.setBoolean(i++,property.isAlcoholAllowed());s.setBoolean(i++,property.isPetsAllowed());
                s.setString(i++,property.getNoticePeriod());s.setBigDecimal(i++,property.getMaintenanceCharges());s.setString(i++,property.getDescription());
                s.setString(i++,property.getNearbyLandmarks());s.setLong(i++,property.getId());s.setLong(i,property.getOwnerId());
                if(s.executeUpdate()!=1)throw new IllegalArgumentException("Listing not found or not owned by this account");
            }
            try(PreparedStatement d=c.prepareStatement("DELETE FROM room_types WHERE property_id=?")){d.setLong(1,property.getId());d.executeUpdate();}
            try(PreparedStatement d=c.prepareStatement("DELETE FROM property_photos WHERE property_id=?")){d.setLong(1,property.getId());d.executeUpdate();}
            try(PreparedStatement d=c.prepareStatement("DELETE FROM property_amenities WHERE property_id=?")){d.setLong(1,property.getId());d.executeUpdate();}
            writeChildren(c,property.getId(),property);c.commit();
        }catch(Exception e){LOG.error("Listing update failed",e);throw new IllegalStateException("Listing could not be updated",e);}
    }
    private void writeChildren(Connection c,long propertyId,Property property)throws SQLException{
        try(PreparedStatement room=c.prepareStatement("INSERT INTO room_types(property_id,sharing,rent,deposit,available_count) VALUES(?,?,?,?,?)")){
            for(RoomType r:property.getRoomTypes()){room.setLong(1,propertyId);room.setString(2,r.getSharing());room.setBigDecimal(3,r.getRent());room.setBigDecimal(4,r.getDeposit());room.setInt(5,r.getAvailableCount());room.addBatch();}room.executeBatch();
        }
        try(PreparedStatement photo=c.prepareStatement("INSERT INTO property_photos(property_id,file_path,is_cover,sort_order) VALUES(?,?,?,?)")){
            for(int x=0;x<property.getPhotos().size();x++){Photo p=property.getPhotos().get(x);photo.setLong(1,propertyId);photo.setString(2,p.getFilePath());photo.setBoolean(3,x==0);photo.setInt(4,x);photo.addBatch();}photo.executeBatch();
        }
        try(PreparedStatement amenity=c.prepareStatement("INSERT IGNORE INTO property_amenities(property_id,amenity_id) SELECT ?,id FROM amenities WHERE name=?")){
            for(String name:property.getAmenities()){amenity.setLong(1,propertyId);amenity.setString(2,name);amenity.addBatch();}amenity.executeBatch();
        }
    }
    @Override public void setStatus(long id,String status,long adminId,String reason){
        try(Connection c=connections.get()){
            c.setAutoCommit(false);
            try(PreparedStatement p=c.prepareStatement("UPDATE properties SET status=?,review_reason=?,reviewed_by=?,reviewed_at=NOW() WHERE id=? AND (?<>'APPROVED' OR EXISTS(SELECT 1 FROM owner_kyc k WHERE k.user_id=properties.owner_id AND k.status='APPROVED'))")){
                p.setString(1,status);p.setString(2,reason);p.setLong(3,adminId);p.setLong(4,id);p.setString(5,status);
                if(p.executeUpdate()!=1)throw new IllegalArgumentException("Listing not found or owner verification is not approved");
            }
            try(PreparedStatement p=c.prepareStatement("INSERT INTO admin_actions(admin_id,target_type,target_id,action,reason) VALUES(?,'PROPERTY',?,?,?)")){
                p.setLong(1,adminId);p.setLong(2,id);p.setString(3,status);p.setString(4,reason);p.executeUpdate();
            }
            c.commit();
        }catch(Exception e){LOG.error("Listing review failed",e);throw new IllegalStateException("Listing review failed",e);}
    }
}
