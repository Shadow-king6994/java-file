package com.nestify.filter;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;
import java.io.IOException;
@WebFilter("/*")
public class FlashFilter implements Filter {
    @Override public void doFilter(ServletRequest request,ServletResponse response,FilterChain chain)throws IOException,ServletException{
        HttpServletRequest req=(HttpServletRequest)request;HttpSession session=req.getSession(false);
        if(session!=null){Object notice=session.getAttribute("notice"),error=session.getAttribute("error");if(notice!=null){req.setAttribute("flashNotice",notice);session.removeAttribute("notice");}if(error!=null){req.setAttribute("flashError",error);session.removeAttribute("error");}}
        chain.doFilter(request,response);
    }
}
