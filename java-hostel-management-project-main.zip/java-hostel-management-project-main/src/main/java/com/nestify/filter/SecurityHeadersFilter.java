package com.nestify.filter;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
@WebFilter("/*")
public class SecurityHeadersFilter implements Filter {
    @Override public void doFilter(ServletRequest request,ServletResponse response,FilterChain chain)throws IOException,ServletException{
        HttpServletResponse res=(HttpServletResponse)response;
        res.setHeader("Content-Security-Policy","default-src 'self'; img-src 'self' data:; style-src 'self' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; script-src 'self'; form-action 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'self'");
        res.setHeader("X-Frame-Options","DENY");res.setHeader("X-Content-Type-Options","nosniff");res.setHeader("Referrer-Policy","strict-origin-when-cross-origin");
        res.setHeader("Permissions-Policy","camera=(), microphone=(), geolocation=()");
        res.setHeader("Cache-Control","no-store");
        chain.doFilter(request,response);
    }
}
