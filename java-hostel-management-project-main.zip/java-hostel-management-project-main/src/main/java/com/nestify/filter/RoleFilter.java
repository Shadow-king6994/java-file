package com.nestify.filter;
import com.nestify.model.User;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;
import java.io.IOException;
@WebFilter({"/owner/*","/tenant/*","/admin/*"})
public class RoleFilter implements Filter {
    @Override public void doFilter(ServletRequest request,ServletResponse response,FilterChain chain)throws IOException,ServletException{
        HttpServletRequest req=(HttpServletRequest)request;HttpServletResponse res=(HttpServletResponse)response;
        HttpSession session=req.getSession(false);
        if(session==null||!(session.getAttribute("authUser") instanceof User)){res.sendRedirect(req.getContextPath()+"/login");return;}
        User user=(User)session.getAttribute("authUser");String path=req.getRequestURI().substring(req.getContextPath().length());
        String required=path.startsWith("/owner/")?"OWNER":path.startsWith("/tenant/")?"TENANT":"ADMIN";
        if(!required.equals(user.getRole())){res.sendError(HttpServletResponse.SC_FORBIDDEN);return;}
        chain.doFilter(request,response);
    }
}
