package com.nestify.filter;
import com.nestify.model.User;
import com.nestify.dao.impl.UserDaoImpl;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;
import java.io.IOException;
@WebFilter({"/owner/*","/tenant/*","/admin/*"})
public class AuthFilter implements Filter {
    @Override public void doFilter(ServletRequest request,ServletResponse response,FilterChain chain)throws IOException,ServletException{
        HttpServletRequest req=(HttpServletRequest)request;HttpServletResponse res=(HttpServletResponse)response;
        HttpSession session=req.getSession(false);
        if(session==null||!(session.getAttribute("authUser") instanceof User user)){res.sendRedirect(req.getContextPath()+"/login");return;}
        User current=new UserDaoImpl().findById(user.getId()).orElse(null);
        if(current==null||!"ACTIVE".equals(current.getStatus())||!current.isEmailVerified()){
            session.invalidate();res.sendRedirect(req.getContextPath()+"/login");return;
        }
        session.setAttribute("authUser",current);
        chain.doFilter(request,response);
    }
}
