package com.nestify.filter;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
@WebFilter("/*")
public class CsrfFilter implements Filter {
    private final SecureRandom random=new SecureRandom();
    @Override public void doFilter(ServletRequest request,ServletResponse response,FilterChain chain)throws IOException,ServletException{
        HttpServletRequest req=(HttpServletRequest)request;HttpServletResponse res=(HttpServletResponse)response;
        HttpSession session=req.getSession(true);
        if(session.getAttribute("csrfToken")==null){byte[] b=new byte[32];random.nextBytes(b);session.setAttribute("csrfToken",Base64.getUrlEncoder().withoutPadding().encodeToString(b));}
        if("POST".equalsIgnoreCase(req.getMethod())){
            String expected=(String)session.getAttribute("csrfToken"),actual=req.getParameter("_csrf");
            if(expected==null||actual==null||!MessageDigest.isEqual(expected.getBytes(java.nio.charset.StandardCharsets.UTF_8),actual.getBytes(java.nio.charset.StandardCharsets.UTF_8))){res.sendError(HttpServletResponse.SC_FORBIDDEN,"Invalid or expired CSRF token");return;}
        }
        chain.doFilter(request,response);
    }
}
