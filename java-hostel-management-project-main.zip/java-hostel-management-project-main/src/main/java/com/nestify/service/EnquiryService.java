package com.nestify.service;
import com.nestify.dao.EnquiryDao;
import com.nestify.dao.NotificationDao;
import com.nestify.dao.PropertyDao;
import com.nestify.dao.UserDao;
import com.nestify.model.Enquiry;
import com.nestify.util.ValidationUtil;
import com.nestify.util.MailUtil;
import java.time.Instant;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class EnquiryService {
    private static final Logger LOG=LoggerFactory.getLogger(EnquiryService.class);
    private final EnquiryDao enquiries;
    private final PropertyDao properties;
    private final UserDao users;
    private final NotificationDao notifications;
    private final MailUtil mail;
    private final ConcurrentHashMap<String,Window> limits=new ConcurrentHashMap<>();
    public EnquiryService(EnquiryDao enquiries,PropertyDao properties,UserDao users,NotificationDao notifications,MailUtil mail){
        this.enquiries=enquiries;this.properties=properties;this.users=users;this.notifications=notifications;this.mail=mail;
    }
    public long submit(Enquiry e,String ip){
        rateLimit("ip:"+ip,5);
        if(e.getTenantId()>0)rateLimit("user:"+e.getTenantId(),5);
        e.setName(ValidationUtil.required(e.getName(),"Name",120));e.setMobile(ValidationUtil.mobile(e.getMobile()));
        e.setEmail(ValidationUtil.email(e.getEmail()));e.setGender(ValidationUtil.enumValue(e.getGender(),"gender","MALE","FEMALE","OTHER"));
        e.setOccupation(ValidationUtil.enumValue(e.getOccupation(),"occupation","STUDENT","WORKING","OTHER"));
        e.setMessage(ValidationUtil.required(e.getMessage(),"Message",2000));
        if(e.getBudget()!=null&&e.getBudget().signum()<0)throw new IllegalArgumentException("Budget cannot be negative");
        long id=enquiries.create(e);
        properties.findPublicById(e.getPropertyId()).ifPresent(property->users.findById(property.getOwnerId()).ifPresent(owner->{
            String subject="New room enquiry";
            String body=e.getName()+" asked about "+property.getTitle()+". Reply to "+e.getEmail()+" or "+e.getMobile()+".";
            try{notifications.create(owner.getId(),subject,body);}catch(RuntimeException ex){LOG.error("Enquiry saved but in-app owner notification failed for user {}",owner.getId(),ex);}
            try{mail.send(owner.getEmail(),subject,body);}catch(Exception ex){LOG.error("Enquiry saved but owner email notification failed for user {}",owner.getId(),ex);}
        }));
        return id;
    }
    private void rateLimit(String key,int max){
        long now=Instant.now().getEpochSecond();
        Window w=limits.compute(key,(k,old)->old==null||now-old.started>=3600?new Window(now,new AtomicInteger()):old);
        if(w.count.incrementAndGet()>max)throw new IllegalArgumentException("Too many enquiries. Please try again later.");
    }
    private record Window(long started,AtomicInteger count){}
}
