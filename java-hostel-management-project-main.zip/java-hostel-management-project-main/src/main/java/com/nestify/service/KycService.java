package com.nestify.service;
import com.nestify.dao.KycDao;
import com.nestify.model.OwnerKyc;
import com.nestify.util.ValidationUtil;
public class KycService {
    private final KycDao dao;
    public KycService(KycDao dao){this.dao=dao;}
    public void submit(OwnerKyc k){
        k.setIdType(ValidationUtil.enumValue(k.getIdType(),"ID type","AADHAAR","PAN","PASSPORT","DRIVING_LICENCE"));
        k.setIdNumber(ValidationUtil.required(k.getIdNumber(),"ID number",80));
        for(String path:new String[]{k.getIdFrontPath(),k.getIdBackPath(),k.getSelfiePath(),k.getOwnershipProofPath()})
            if(path==null||path.isBlank())throw new IllegalArgumentException("All identity and ownership documents are required");
        dao.save(k);
    }
}
