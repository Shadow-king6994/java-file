package com.nestify.service;
import com.nestify.dao.PropertyDao;
import com.nestify.model.Property;
import com.nestify.model.RoomType;
import com.nestify.util.ValidationUtil;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.*;
public class ListingService {
    private final PropertyDao properties;
    private static final Set<String> AMENITIES=Set.of("WiFi","AC","Laundry","Power backup","CCTV","Geyser","Parking","Housekeeping","Attached bath","Fridge","TV","Study table");
    public ListingService(PropertyDao properties){this.properties=properties;}
    public List<Property> search(Map<String,String> filters,int page){
        if(page<1)page=1;
        if(page>10000)page=10000;
        Map<String,String> safe=new HashMap<>();
        for(String key:List.of("city","locality"))if(filters.get(key)!=null)safe.put(key,ValidationUtil.required(filters.get(key),key,120));
        if(filters.get("type")!=null)safe.put("type",ValidationUtil.enumValue(filters.get("type"),"type","PG","HOSTEL"));
        if(filters.get("gender")!=null)safe.put("gender",ValidationUtil.enumValue(filters.get("gender"),"gender","MALE","FEMALE","COED"));
        if(filters.get("food")!=null)safe.put("food",ValidationUtil.enumValue(filters.get("food"),"food","INCLUDED","AVAILABLE","NOT_AVAILABLE"));
        if(filters.get("sharing")!=null)safe.put("sharing",ValidationUtil.enumValue(filters.get("sharing"),"sharing","SINGLE","DOUBLE","TRIPLE","FOUR_PLUS"));
        if(filters.get("amenity")!=null)safe.put("amenity",ValidationUtil.enumValue(filters.get("amenity"),"amenity","WIFI","AC","LAUNDRY","POWER BACKUP","CCTV","GEYSER","PARKING","HOUSEKEEPING","ATTACHED BATH","FRIDGE","TV","STUDY TABLE"));
        if(filters.get("sort")!=null)safe.put("sort",ValidationUtil.enumValue(filters.get("sort"),"sort","NEWEST","RENT"));
        for(String key:List.of("minPrice","maxPrice"))if(filters.get(key)!=null&&!filters.get(key).isBlank())safe.put(key,ValidationUtil.money(filters.get(key),key).toPlainString());
        if(safe.containsKey("minPrice")&&safe.containsKey("maxPrice")&&new BigDecimal(safe.get("minPrice")).compareTo(new BigDecimal(safe.get("maxPrice")))>0)
            throw new IllegalArgumentException("Minimum rent cannot be higher than maximum rent");
        if(filters.containsKey("verified"))safe.put("verified","true");
        return properties.search(safe,page,13);
    }
    public long create(Property p){
        p.setTitle(ValidationUtil.required(p.getTitle(),"Title",180));
        p.setCity(ValidationUtil.required(p.getCity(),"City",100));
        p.setLocality(ValidationUtil.required(p.getLocality(),"Locality",120));
        p.setFullAddress(ValidationUtil.required(p.getFullAddress(),"Address",500));
        p.setPincode(ValidationUtil.required(p.getPincode(),"Pincode",6));
        if(!p.getPincode().matches("\\d{6}"))throw new IllegalArgumentException("Enter a valid 6 digit pincode");
        p.setDescription(ValidationUtil.required(p.getDescription(),"Description",5000));
        if(p.getAvailableFrom()==null||p.getAvailableFrom().before(new Date(System.currentTimeMillis()-86400000L))||p.getTotalRooms()<1||p.getTotalRooms()>1000)throw new IllegalArgumentException("Choose a future availability date and a valid room count");
        p.setPropertyType(ValidationUtil.enumValue(p.getPropertyType(),"property type","PG","HOSTEL"));
        p.setSuitableFor(ValidationUtil.enumValue(p.getSuitableFor(),"suitable for","MALE","FEMALE","COED"));
        p.setFoodOption(ValidationUtil.enumValue(p.getFoodOption(),"food option","INCLUDED","AVAILABLE","NOT_AVAILABLE"));
        if(p.getRoomTypes().isEmpty())throw new IllegalArgumentException("Add at least one room type");
        if(p.getPhotos().size()<4||p.getPhotos().size()>12)throw new IllegalArgumentException("A listing must have 4 to 12 property photos");
        for(RoomType room:p.getRoomTypes()){
            room.setSharing(ValidationUtil.enumValue(room.getSharing(),"sharing","SINGLE","DOUBLE","TRIPLE","FOUR_PLUS"));
            if(room.getRent()==null||room.getDeposit()==null||room.getRent().signum()<0||room.getDeposit().signum()<0||room.getAvailableCount()<1)throw new IllegalArgumentException("Room rent, deposit and availability must be valid");
        }
        p.setAmenities(p.getAmenities().stream().filter(AMENITIES::contains).distinct().toList());
        if(p.getMaintenanceCharges()==null)p.setMaintenanceCharges(BigDecimal.ZERO);
        if(p.getId()>0){properties.update(p);return p.getId();}
        return properties.create(p);
    }
    public static Date parseDate(String value,String field){
        try{Date date=Date.valueOf(ValidationUtil.required(value,field,10));if(date.before(new Date(System.currentTimeMillis()-86400000L)))throw new IllegalArgumentException(field+" cannot be in the past");return date;}
        catch(IllegalArgumentException e){throw new IllegalArgumentException("Enter a valid "+field.toLowerCase()+" date");}
    }
}
