package com.nestify.service;
import com.nestify.dao.UserDao;
import com.nestify.model.User;
import com.nestify.util.MailUtil;
import com.nestify.util.OtpUtil;
import com.nestify.util.PasswordUtil;
import com.nestify.util.ValidationUtil;
import java.util.Optional;

public class AuthService {
    private final UserDao users;
    private final MailUtil mail;
    public AuthService(UserDao users,MailUtil mail){this.users=users;this.mail=mail;}
    public long register(String name,String mobile,String email,String password,String role){
        String cleanName=ValidationUtil.required(name,"Name",120);
        String cleanMobile=ValidationUtil.mobile(mobile);
        String cleanEmail=ValidationUtil.email(email);
        if(password==null||password.length()<10||password.getBytes(java.nio.charset.StandardCharsets.UTF_8).length>72)throw new IllegalArgumentException("Password must be at least 10 characters and at most 72 UTF-8 bytes");
        String cleanRole=ValidationUtil.enumValue(role,"role","TENANT","OWNER");
        User user=new User();user.setName(cleanName);user.setMobile(cleanMobile);user.setEmail(cleanEmail);
        user.setPasswordHash(PasswordUtil.hash(password));user.setRole(cleanRole);
        return users.create(user);
    }
    public void sendOtp(long id,String email)throws Exception{
        String otp=OtpUtil.generate();users.saveOtp(id,OtpUtil.hash(otp));
        mail.send(email,"Your NESTIFY verification code","Your verification code is "+otp+". It expires in 10 minutes. Do not share this code.");
    }
    public User verify(long id,String otp){
        if(otp==null||!otp.matches("\\d{6}")||!users.consumeOtp(id,OtpUtil.hash(otp)))throw new IllegalArgumentException("That code is invalid or expired. Request a new one.");
        users.markVerified(id);
        return users.findById(id).orElseThrow(()->new IllegalStateException("Verified account was not found"));
    }
    public Optional<User> authenticate(String email,String password){
        String normalized=ValidationUtil.email(email);
        Optional<User> found=users.findByEmail(normalized);
        if(found.isEmpty())return Optional.empty();
        User user=found.get();
        if(!users.loginAllowed(user.getId()))return Optional.empty();
        if(!PasswordUtil.matches(password,user.getPasswordHash())){users.recordLoginFailure(user.getId());return Optional.empty();}
        users.resetLoginFailures(user.getId());
        return Optional.of(user);
    }
}
