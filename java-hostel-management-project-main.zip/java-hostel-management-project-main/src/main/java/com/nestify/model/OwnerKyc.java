package com.nestify.model;
public class OwnerKyc {
    private long id,userId;
    private String idType,idNumber,idFrontPath,idBackPath,selfiePath,ownershipProofPath,status,reviewReason;
    public long getId(){return id;} public void setId(long v){id=v;}
    public long getUserId(){return userId;} public void setUserId(long v){userId=v;}
    public String getIdType(){return idType;} public void setIdType(String v){idType=v;}
    public String getIdNumber(){return idNumber;} public void setIdNumber(String v){idNumber=v;}
    public String getIdFrontPath(){return idFrontPath;} public void setIdFrontPath(String v){idFrontPath=v;}
    public String getIdBackPath(){return idBackPath;} public void setIdBackPath(String v){idBackPath=v;}
    public String getSelfiePath(){return selfiePath;} public void setSelfiePath(String v){selfiePath=v;}
    public String getOwnershipProofPath(){return ownershipProofPath;} public void setOwnershipProofPath(String v){ownershipProofPath=v;}
    public String getStatus(){return status;} public void setStatus(String v){status=v;}
    public String getReviewReason(){return reviewReason;} public void setReviewReason(String v){reviewReason=v;}
}
