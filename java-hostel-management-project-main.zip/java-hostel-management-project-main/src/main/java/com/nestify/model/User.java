package com.nestify.model;

public class User {
    private long id;
    private String name, mobile, email, passwordHash, role, status;
    private boolean emailVerified;
    public User() {}
    public User(long id, String name, String mobile, String email, String passwordHash, String role, boolean emailVerified) {
        this.id=id; this.name=name; this.mobile=mobile; this.email=email; this.passwordHash=passwordHash; this.role=role; this.emailVerified=emailVerified;
    }
    public long getId(){return id;} public void setId(long v){id=v;}
    public String getName(){return name;} public void setName(String v){name=v;}
    public String getMobile(){return mobile;} public void setMobile(String v){mobile=v;}
    public String getEmail(){return email;} public void setEmail(String v){email=v;}
    public String getPasswordHash(){return passwordHash;} public void setPasswordHash(String v){passwordHash=v;}
    public String getRole(){return role;} public void setRole(String v){role=v;}
    public String getStatus(){return status;} public void setStatus(String v){status=v;}
    public boolean isEmailVerified(){return emailVerified;} public void setEmailVerified(boolean v){emailVerified=v;}
}
