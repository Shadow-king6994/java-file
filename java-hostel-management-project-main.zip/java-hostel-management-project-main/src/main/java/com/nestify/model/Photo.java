package com.nestify.model;
public class Photo {
    private long id, propertyId;
    private String filePath;
    private boolean cover;
    private int sortOrder;
    public long getId(){return id;} public void setId(long v){id=v;}
    public long getPropertyId(){return propertyId;} public void setPropertyId(long v){propertyId=v;}
    public String getFilePath(){return filePath;} public void setFilePath(String v){filePath=v;}
    public boolean isCover(){return cover;} public void setCover(boolean v){cover=v;}
    public int getSortOrder(){return sortOrder;} public void setSortOrder(int v){sortOrder=v;}
}
