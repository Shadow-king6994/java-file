package com.nestify.model;

import java.math.BigDecimal;

public class RoomType {
    private long id, propertyId;
    private String sharing;
    private BigDecimal rent=BigDecimal.ZERO, deposit=BigDecimal.ZERO;
    private int availableCount;
    public long getId(){return id;} public void setId(long v){id=v;}
    public long getPropertyId(){return propertyId;} public void setPropertyId(long v){propertyId=v;}
    public String getSharing(){return sharing;} public void setSharing(String v){sharing=v;}
    public BigDecimal getRent(){return rent;} public void setRent(BigDecimal v){rent=v;}
    public BigDecimal getDeposit(){return deposit;} public void setDeposit(BigDecimal v){deposit=v;}
    public int getAvailableCount(){return availableCount;} public void setAvailableCount(int v){availableCount=v;}
}
