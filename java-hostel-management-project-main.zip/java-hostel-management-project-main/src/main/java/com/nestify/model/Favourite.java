package com.nestify.model;
public class Favourite { private long userId,propertyId; public long getUserId(){return userId;} public void setUserId(long v){userId=v;} public long getPropertyId(){return propertyId;} public void setPropertyId(long v){propertyId=v;} }
