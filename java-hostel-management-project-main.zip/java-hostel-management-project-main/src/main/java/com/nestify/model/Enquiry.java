package com.nestify.model;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
public class Enquiry {
    private long id, propertyId, tenantId;
    private String name,mobile,email,gender,occupation,collegeCompany,stayDuration,roomInterest,message,status,preferredVisitSlot;
    private Date moveInDate,preferredVisitDate;
    private BigDecimal budget;
    private Timestamp createdAt;
    public long getId(){return id;} public void setId(long v){id=v;}
    public long getPropertyId(){return propertyId;} public void setPropertyId(long v){propertyId=v;}
    public long getTenantId(){return tenantId;} public void setTenantId(long v){tenantId=v;}
    public String getName(){return name;} public void setName(String v){name=v;}
    public String getMobile(){return mobile;} public void setMobile(String v){mobile=v;}
    public String getEmail(){return email;} public void setEmail(String v){email=v;}
    public String getGender(){return gender;} public void setGender(String v){gender=v;}
    public String getOccupation(){return occupation;} public void setOccupation(String v){occupation=v;}
    public String getCollegeCompany(){return collegeCompany;} public void setCollegeCompany(String v){collegeCompany=v;}
    public String getStayDuration(){return stayDuration;} public void setStayDuration(String v){stayDuration=v;}
    public String getRoomInterest(){return roomInterest;} public void setRoomInterest(String v){roomInterest=v;}
    public String getMessage(){return message;} public void setMessage(String v){message=v;}
    public String getStatus(){return status;} public void setStatus(String v){status=v;}
    public String getPreferredVisitSlot(){return preferredVisitSlot;} public void setPreferredVisitSlot(String v){preferredVisitSlot=v;}
    public Date getMoveInDate(){return moveInDate;} public void setMoveInDate(Date v){moveInDate=v;}
    public Date getPreferredVisitDate(){return preferredVisitDate;} public void setPreferredVisitDate(Date v){preferredVisitDate=v;}
    public BigDecimal getBudget(){return budget;} public void setBudget(BigDecimal v){budget=v;}
    public Timestamp getCreatedAt(){return createdAt;} public void setCreatedAt(Timestamp v){createdAt=v;}
}
