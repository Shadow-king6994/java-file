package com.nestify.model;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class Property {
    private long id, ownerId;
    private String title, propertyType, suitableFor, city, locality, fullAddress, pincode, foodOption, mealDetails,
        curfew, visitorRules, noticePeriod, description, nearbyLandmarks, status, reviewReason, ownerName, ownerMobile;
    private int totalRooms;
    private Date availableFrom;
    private BigDecimal maintenanceCharges=BigDecimal.ZERO, startingRent=BigDecimal.ZERO;
    private boolean smokingAllowed, alcoholAllowed, petsAllowed, verifiedOwner;
    private List<RoomType> roomTypes=new ArrayList<>();
    private List<Photo> photos=new ArrayList<>();
    private List<String> amenities=new ArrayList<>();
    public long getId(){return id;} public void setId(long v){id=v;}
    public long getOwnerId(){return ownerId;} public void setOwnerId(long v){ownerId=v;}
    public String getOwnerName(){return ownerName;} public void setOwnerName(String v){ownerName=v;}
    public String getOwnerMobile(){return ownerMobile;} public void setOwnerMobile(String v){ownerMobile=v;}
    public String getTitle(){return title;} public void setTitle(String v){title=v;}
    public String getPropertyType(){return propertyType;} public void setPropertyType(String v){propertyType=v;}
    public String getSuitableFor(){return suitableFor;} public void setSuitableFor(String v){suitableFor=v;}
    public String getCity(){return city;} public void setCity(String v){city=v;}
    public String getLocality(){return locality;} public void setLocality(String v){locality=v;}
    public String getFullAddress(){return fullAddress;} public void setFullAddress(String v){fullAddress=v;}
    public String getPincode(){return pincode;} public void setPincode(String v){pincode=v;}
    public String getFoodOption(){return foodOption;} public void setFoodOption(String v){foodOption=v;}
    public String getMealDetails(){return mealDetails;} public void setMealDetails(String v){mealDetails=v;}
    public String getCurfew(){return curfew;} public void setCurfew(String v){curfew=v;}
    public String getVisitorRules(){return visitorRules;} public void setVisitorRules(String v){visitorRules=v;}
    public String getNoticePeriod(){return noticePeriod;} public void setNoticePeriod(String v){noticePeriod=v;}
    public String getDescription(){return description;} public void setDescription(String v){description=v;}
    public String getNearbyLandmarks(){return nearbyLandmarks;} public void setNearbyLandmarks(String v){nearbyLandmarks=v;}
    public String getStatus(){return status;} public void setStatus(String v){status=v;}
    public String getReviewReason(){return reviewReason;} public void setReviewReason(String v){reviewReason=v;}
    public int getTotalRooms(){return totalRooms;} public void setTotalRooms(int v){totalRooms=v;}
    public Date getAvailableFrom(){return availableFrom;} public void setAvailableFrom(Date v){availableFrom=v;}
    public BigDecimal getMaintenanceCharges(){return maintenanceCharges;} public void setMaintenanceCharges(BigDecimal v){maintenanceCharges=v;}
    public BigDecimal getStartingRent(){return startingRent;} public void setStartingRent(BigDecimal v){startingRent=v;}
    public boolean isSmokingAllowed(){return smokingAllowed;} public void setSmokingAllowed(boolean v){smokingAllowed=v;}
    public boolean isAlcoholAllowed(){return alcoholAllowed;} public void setAlcoholAllowed(boolean v){alcoholAllowed=v;}
    public boolean isPetsAllowed(){return petsAllowed;} public void setPetsAllowed(boolean v){petsAllowed=v;}
    public boolean isVerifiedOwner(){return verifiedOwner;} public void setVerifiedOwner(boolean v){verifiedOwner=v;}
    public List<RoomType> getRoomTypes(){return roomTypes;} public void setRoomTypes(List<RoomType> v){roomTypes=v;}
    public List<Photo> getPhotos(){return photos;} public void setPhotos(List<Photo> v){photos=v;}
    public List<String> getAmenities(){return amenities;} public void setAmenities(List<String> v){amenities=v;}
}
