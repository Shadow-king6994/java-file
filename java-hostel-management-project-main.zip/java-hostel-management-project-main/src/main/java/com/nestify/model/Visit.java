package com.nestify.model;
import java.sql.Date;
public class Visit {
    private long id,propertyId,tenantId; private Date requestedDate; private String timeSlot,status,tenantName,tenantEmail,tenantMobile;
    public long getId(){return id;} public void setId(long v){id=v;}
    public long getPropertyId(){return propertyId;} public void setPropertyId(long v){propertyId=v;}
    public long getTenantId(){return tenantId;} public void setTenantId(long v){tenantId=v;}
    public Date getRequestedDate(){return requestedDate;} public void setRequestedDate(Date v){requestedDate=v;}
    public String getTimeSlot(){return timeSlot;} public void setTimeSlot(String v){timeSlot=v;}
    public String getStatus(){return status;} public void setStatus(String v){status=v;}
    public String getTenantName(){return tenantName;} public void setTenantName(String v){tenantName=v;}
    public String getTenantEmail(){return tenantEmail;} public void setTenantEmail(String v){tenantEmail=v;}
    public String getTenantMobile(){return tenantMobile;} public void setTenantMobile(String v){tenantMobile=v;}
}
