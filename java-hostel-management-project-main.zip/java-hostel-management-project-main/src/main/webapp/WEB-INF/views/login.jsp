<%@ include file="/WEB-INF/views/fragments/head.jspf" %>
<%@ include file="/WEB-INF/views/fragments/header.jspf" %>
<section class="page-shell container"><form class="form-card" action="${pageContext.request.contextPath}/auth/login" method="post">
  <span class="eyebrow">WELCOME BACK</span><h1>Come on in.</h1><p>Sign in to pick up where you left off.</p><c:if test="${not empty error}"><n:alert message="${error}"/></c:if>
  <input type="hidden" name="_csrf" value="${sessionScope.csrfToken}">
  <div class="field"><label for="email">Email</label><input id="email" name="email" type="email" required autocomplete="email" maxlength="190"></div>
  <div class="field"><label for="password">Password</label><input id="password" name="password" type="password" required autocomplete="current-password"></div>
  <button class="button button-black" type="submit">LOG IN →</button><p>New to NESTIFY? <a href="${pageContext.request.contextPath}/register">Create an account.</a></p>
</form></section>
<%@ include file="/WEB-INF/views/fragments/footer.jspf" %>
