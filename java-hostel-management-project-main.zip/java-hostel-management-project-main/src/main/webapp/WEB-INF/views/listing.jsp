<%@ include file="/WEB-INF/views/fragments/head.jspf" %>
<%@ include file="/WEB-INF/views/fragments/header.jspf" %>
<section class="page-shell"><div class="container">
  <p><a class="text-link" href="${pageContext.request.contextPath}/search">← BACK TO RESULTS</a></p>
  <div class="listing-detail">
    <div>
      <div class="gallery ${empty property.photos?'gallery-sample':''}">
        <c:choose><c:when test="${not empty property.photos}"><c:forEach items="${property.photos}" var="photo" varStatus="loop"><img class="${loop.first?'gallery-main':''}" src="${pageContext.request.contextPath}/files/${photo.filePath}" alt="Photo ${loop.count} of this accommodation"></c:forEach></c:when><c:otherwise><c:set var="samplePhoto" value="${pageContext.request.contextPath}/assets/images/stay-${property.id mod 4 + 1}.jpg"/><img class="gallery-main" src="${samplePhoto}" alt="Sample accommodation photo"></c:otherwise></c:choose>
      </div>
      <section class="section-tight"><span class="eyebrow">THE DETAILS</span><h2>Description</h2><p><c:out value="${property.description}"/></p>
        <div class="two-col"><div><h3>Amenities</h3><div class="badge-row"><c:forEach items="${property.amenities}" var="amenity"><span class="badge badge-mint"><c:out value="${amenity}"/></span></c:forEach></div></div><div><h3>House rules</h3><ul><c:if test="${not empty property.curfew}"><li>Curfew: <c:out value="${property.curfew}"/></li></c:if><c:if test="${not empty property.visitorRules}"><li>Visitors: <c:out value="${property.visitorRules}"/></li></c:if><li>Smoking: ${property.smokingAllowed?'Allowed':'Not allowed'}</li><li>Alcohol: ${property.alcoholAllowed?'Allowed':'Not allowed'}</li><li>Pets: ${property.petsAllowed?'Allowed':'Not allowed'}</li></ul></div></div>
        <p><strong>Nearby:</strong> <c:out value="${property.nearbyLandmarks}"/></p>
      </section>
    </div>
    <aside class="detail-panel">
      <div class="badge-row"><span class="badge badge-blue"><c:out value="${property.propertyType}"/></span><span class="badge badge-mint"><c:out value="${property.suitableFor}"/></span><c:if test="${property.verifiedOwner}"><span class="badge badge-verified">VERIFIED ✔</span></c:if></div>
      <h1><c:out value="${property.title}"/></h1><p><c:out value="${property.locality}"/>, <c:out value="${property.city}"/> · <c:out value="${property.pincode}"/></p>
      <section class="owner-contact" aria-label="Owner contact details"><span class="eyebrow">YOUR HOST</span><strong><c:out value="${property.ownerName}"/></strong><a href="tel:<c:out value='${property.ownerMobile}'/>"><c:out value="${property.ownerMobile}"/></a></section>
      <c:if test="${not empty sessionScope.authUser and sessionScope.authUser.role eq 'TENANT'}"><form action="${pageContext.request.contextPath}/favourite" method="post"><input type="hidden" name="_csrf" value="${sessionScope.csrfToken}"><input type="hidden" name="propertyId" value="${property.id}"><button class="button button-pink" type="submit">${isFavourite?'♥ SAVED':'♡ SAVE THIS NEST'}</button></form></c:if>
      <div class="divider"></div><h2>Room options</h2>
      <table class="room-table"><thead><tr><th>Sharing</th><th>Rent/mo</th><th>Deposit</th></tr></thead><tbody><c:forEach items="${property.roomTypes}" var="room"><tr><td><c:out value="${room.sharing}"/></td><td>₹<c:out value="${room.rent}"/></td><td>₹<c:out value="${room.deposit}"/></td></tr></c:forEach></tbody></table>
      <p class="mono">FOOD: <c:out value="${property.foodOption}"/> · AVAILABLE: <c:out value="${property.availableFrom}"/> · ROOMS: <c:out value="${property.totalRooms}"/></p>
      <c:if test="${property.maintenanceCharges gt 0}"><p>Maintenance: ₹<c:out value="${property.maintenanceCharges}"/>/mo</p></c:if>
      <div class="divider"></div>
      <h2>Ask about this room</h2>
      <form action="${pageContext.request.contextPath}/enquiry" method="post">
        <input type="hidden" name="_csrf" value="${sessionScope.csrfToken}"><input type="hidden" name="propertyId" value="${property.id}">
        <div class="field"><label for="name">Your name</label><input id="name" name="name" required maxlength="120" value="<c:out value='${sessionScope.authUser.name}'/>"></div>
        <div class="field"><label for="mobile">Mobile</label><input id="mobile" name="mobile" required pattern="\+?[0-9]{10,15}"></div>
        <div class="field"><label for="email">Email</label><input id="email" name="email" type="email" required maxlength="190" value="<c:out value='${sessionScope.authUser.email}'/>"></div>
        <div class="form-grid"><div class="field"><label for="gender">Gender</label><select id="gender" name="gender" required><option value="OTHER">Prefer not to say</option><option value="MALE">Male</option><option value="FEMALE">Female</option></select></div><div class="field"><label for="occupation">I am</label><select id="occupation" name="occupation"><option value="STUDENT">Student</option><option value="WORKING">Working</option><option value="OTHER">Other</option></select></div></div>
        <div class="field"><label for="collegeCompany">College / company</label><input id="collegeCompany" name="collegeCompany" maxlength="180"></div>
        <div class="form-grid"><div class="field"><label for="moveInDate">Move-in date</label><input id="moveInDate" name="moveInDate" type="date"></div><div class="field"><label for="stayDuration">Stay duration</label><input id="stayDuration" name="stayDuration" maxlength="60" placeholder="e.g. 6 months"></div></div>
        <div class="form-grid"><div class="field"><label for="preferredVisitDate">Preferred visit date</label><input id="preferredVisitDate" name="preferredVisitDate" type="date"></div><div class="field"><label for="preferredVisitSlot">Preferred visit slot</label><select id="preferredVisitSlot" name="preferredVisitSlot"><option value="">No preference</option><option>Morning</option><option>Afternoon</option><option>Evening</option></select></div></div>
        <div class="form-grid"><div class="field"><label for="roomInterest">Room type</label><select id="roomInterest" name="roomInterest"><option value="">Any</option><c:forEach items="${property.roomTypes}" var="room"><option value="${room.sharing}"><c:out value="${room.sharing}"/></option></c:forEach></select></div><div class="field"><label for="budget">Monthly budget</label><input id="budget" name="budget" type="number" min="0"></div></div>
        <div class="field"><label for="message">Message</label><textarea id="message" name="message" required maxlength="2000" placeholder="Tell the owner what you're looking for."></textarea></div>
        <button class="button button-black" type="submit">SEND ENQUIRY →</button>
      </form>
      <details class="detail-disclosure"><summary class="text-link">REQUEST A VISIT</summary><form action="${pageContext.request.contextPath}/visit" method="post"><input type="hidden" name="_csrf" value="${sessionScope.csrfToken}"><input type="hidden" name="propertyId" value="${property.id}"><div class="field"><label for="visit-date">Preferred date</label><input id="visit-date" type="date" name="requestedDate" required></div><div class="field"><label for="visit-slot">Time slot</label><select id="visit-slot" name="timeSlot"><option>Morning</option><option>Afternoon</option><option>Evening</option></select></div><button class="button" type="submit">REQUEST VISIT</button></form></details>
      <button class="button button-pink detail-disclosure" type="button" data-modal-open="report-modal">REPORT THIS LISTING</button>
      <dialog class="modal-panel" id="report-modal" aria-labelledby="report-title"><div class="modal-heading"><h2 id="report-title">Flag a concern.</h2><button class="button button-outline" type="button" data-modal-close>× CLOSE</button></div><form action="${pageContext.request.contextPath}/report" method="post"><input type="hidden" name="_csrf" value="${sessionScope.csrfToken}"><input type="hidden" name="propertyId" value="${property.id}"><div class="field"><label for="report-reason">Reason</label><select id="report-reason" name="reason"><option>Suspicious listing</option><option>Incorrect information</option><option>Unsafe or discriminatory</option></select></div><div class="field"><label for="report-details">Details</label><textarea id="report-details" name="details" maxlength="1500"></textarea></div><button class="button button-pink" type="submit">SEND REPORT</button></form></dialog>
    </aside>
  </div>
</div></section>
<%@ include file="/WEB-INF/views/fragments/footer.jspf" %>
