<%@ include file="/WEB-INF/views/fragments/head.jspf" %>
<%@ include file="/WEB-INF/views/fragments/header.jspf" %>
<section class="page-shell container"><div class="empty-state"><span class="eyebrow">500 · SOMETHING'S OFF</span><h1 class="page-title">We'll get it sorted.</h1><p>The request could not be completed. Try again in a moment.</p><a class="button" href="${pageContext.request.contextPath}/">GO HOME</a></div></section>
<%@ include file="/WEB-INF/views/fragments/footer.jspf" %>
