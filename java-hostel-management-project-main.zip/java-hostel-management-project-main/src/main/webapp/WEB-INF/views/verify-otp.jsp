<%@ include file="/WEB-INF/views/fragments/head.jspf" %>
<%@ include file="/WEB-INF/views/fragments/header.jspf" %>
<section class="page-shell container"><div class="form-card">
  <span class="eyebrow">ONE LAST THING</span><h1>Check your inbox.</h1><p>Enter the 6-digit code we sent to your email. It expires in 10 minutes.</p><c:if test="${not empty error}"><n:alert message="${error}"/></c:if>
  <form action="${pageContext.request.contextPath}/auth/verify" method="post"><input type="hidden" name="_csrf" value="${sessionScope.csrfToken}"><div class="field"><label for="otp">Verification code</label><input id="otp" name="otp" inputmode="numeric" pattern="[0-9]{6}" minlength="6" maxlength="6" required autocomplete="one-time-code"></div><button class="button button-black" type="submit">VERIFY EMAIL →</button></form>
  <form action="${pageContext.request.contextPath}/auth/resend" method="post" class="resend-form"><input type="hidden" name="_csrf" value="${sessionScope.csrfToken}"><button class="button button-outline" type="submit">SEND A NEW CODE</button></form>
</div></section>
<%@ include file="/WEB-INF/views/fragments/footer.jspf" %>
