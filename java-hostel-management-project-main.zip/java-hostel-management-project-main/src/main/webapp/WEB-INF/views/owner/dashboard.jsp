<%@ include file="/WEB-INF/views/fragments/head.jspf" %>
<%@ include file="/WEB-INF/views/fragments/header.jspf" %>
<section class="page-shell"><div class="container">
  <span class="eyebrow">OWNER STUDIO</span><h1 class="page-title">Your place. Your people.</h1>
  <nav class="owner-nav"><a class="button button-outline" href="${pageContext.request.contextPath}/owner/dashboard">OVERVIEW</a><a class="button button-outline" href="${pageContext.request.contextPath}/owner/onboarding">IDENTITY CHECK</a><a class="button button-outline" href="${pageContext.request.contextPath}/owner/enquiries">ENQUIRY INBOX</a><a class="button" href="${pageContext.request.contextPath}/owner/listing/new">NEW LISTING +</a></nav>
  <div class="dashboard-grid">
    <section class="panel"><h2>Verification status</h2>
      <c:choose><c:when test="${empty kyc}"><p>Your identity and property documents have not been submitted yet.</p><a class="button button-pink" href="${pageContext.request.contextPath}/owner/onboarding">START VERIFICATION</a></c:when>
      <c:otherwise><div class="status-line"><n:badge label="${kyc.status}" tone="${kyc.status eq 'APPROVED'?'approved':kyc.status eq 'REJECTED'?'rejected':kyc.status eq 'NEEDS_MORE_INFO'?'needs-info':'pending'}"/></div><c:if test="${not empty kyc.reviewReason}"><p><strong>Review note:</strong> <c:out value="${kyc.reviewReason}"/></p></c:if><c:if test="${kyc.status ne 'APPROVED'}"><a class="text-link" href="${pageContext.request.contextPath}/owner/onboarding">VIEW OR RESUBMIT DOCUMENTS →</a></c:if></c:otherwise></c:choose>
    </section>
    <section class="panel"><h2>Ready to list?</h2><p>Listings are visible only after both owner and property review.</p><c:choose><c:when test="${not empty kyc and kyc.status eq 'APPROVED'}"><a class="button button-mint" href="${pageContext.request.contextPath}/owner/listing/new">CREATE A LISTING →</a></c:when><c:otherwise><a class="button button-outline" href="${pageContext.request.contextPath}/owner/onboarding">VERIFY FIRST</a></c:otherwise></c:choose></section>
  </div>
  <section class="section-tight"><div class="section-heading"><h2>Your listings</h2><span class="mono"><c:out value="${properties.size()}"/> TOTAL</span></div>
    <c:choose><c:when test="${not empty properties}"><div class="grid"><c:forEach items="${properties}" var="property"><article class="panel"><div class="badge-row"><span class="badge badge-${property.status eq 'APPROVED'?'approved':property.status eq 'REJECTED'?'rejected':property.status eq 'NEEDS_MORE_INFO'?'needs-info':'pending'}"><c:out value="${property.status}"/></span></div><h3><c:out value="${property.title}"/></h3><p><c:out value="${property.locality}"/>, <c:out value="${property.city}"/></p><c:if test="${not empty property.reviewReason}"><p><c:out value="${property.reviewReason}"/></p></c:if><a class="text-link" href="${pageContext.request.contextPath}/owner/listing/edit?id=${property.id}">EDIT LISTING →</a> <c:if test="${property.status eq 'APPROVED'}"><a class="text-link" href="${pageContext.request.contextPath}/listing?id=${property.id}">VIEW LIVE LISTING →</a></c:if></article></c:forEach></div></c:when>
    <c:otherwise><div class="empty-state"><h3>No listings yet.</h3><p>Start with identity verification. We'll guide you through the rest.</p></div></c:otherwise></c:choose>
  </section>
</div></section>
<%@ include file="/WEB-INF/views/fragments/footer.jspf" %>
