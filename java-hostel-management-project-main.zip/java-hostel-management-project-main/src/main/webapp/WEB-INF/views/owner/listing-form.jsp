<%@ include file="/WEB-INF/views/fragments/head.jspf" %>
<%@ include file="/WEB-INF/views/fragments/header.jspf" %>
<section class="page-shell container">
  <div class="page-intro"><span class="eyebrow">OWNER STUDIO · STEP 2 OF 2</span><h1 class="page-title">Make room for someone.</h1><p>Tell the truth about the room, the rent and the rules. Add 4–12 real property photos. Your listing stays private until it's approved.</p></div>
  <c:if test="${not empty error}"><n:alert message="${error}"/></c:if>
  <form class="form-card" action="${pageContext.request.contextPath}/owner/listing/${empty property?'new':'edit'}" method="post" enctype="multipart/form-data">
    <input type="hidden" name="_csrf" value="${sessionScope.csrfToken}">
    <c:if test="${not empty property}"><input type="hidden" name="propertyId" value="${property.id}"></c:if>
    <h2>About the place</h2>
    <div class="field"><label for="title">Listing title</label><input id="title" name="title" required maxlength="180" placeholder="A sunny PG near the metro" value="<c:out value='${property.title}'/>"></div>
    <div class="form-grid">
      <div class="field"><label for="propertyType">Listing type</label><select id="propertyType" name="propertyType"><option ${property.propertyType eq 'PG'?'selected':''}>PG</option><option ${property.propertyType eq 'HOSTEL'?'selected':''}>HOSTEL</option></select></div>
      <div class="field"><label for="suitableFor">Suitable for</label><select id="suitableFor" name="suitableFor"><option ${property.suitableFor eq 'MALE'?'selected':''}>MALE</option><option ${property.suitableFor eq 'FEMALE'?'selected':''}>FEMALE</option><option ${property.suitableFor eq 'COED'?'selected':''}>COED</option></select></div>
      <div class="field"><label for="city">City</label><input id="city" name="city" required maxlength="100" value="<c:out value='${property.city}'/>"></div>
      <div class="field"><label for="locality">Locality</label><input id="locality" name="locality" required maxlength="120" value="<c:out value='${property.locality}'/>"></div>
      <div class="field full"><label for="fullAddress">Full address</label><input id="fullAddress" name="fullAddress" required maxlength="500" value="<c:out value='${property.fullAddress}'/>"></div>
      <div class="field"><label for="pincode">PIN code</label><input id="pincode" name="pincode" required pattern="[0-9]{6}" maxlength="6" value="<c:out value='${property.pincode}'/>"></div>
      <div class="field"><label for="totalRooms">Total rooms</label><input id="totalRooms" name="totalRooms" type="number" min="1" max="1000" required value="<c:out value='${property.totalRooms}'/>"></div>
      <div class="field"><label for="availableFrom">Available from</label><input id="availableFrom" name="availableFrom" type="date" required value="<c:out value='${property.availableFrom}'/>"></div>
      <div class="field"><label for="foodOption">Food</label><select id="foodOption" name="foodOption"><option value="INCLUDED" ${property.foodOption eq 'INCLUDED'?'selected':''}>Meals included</option><option value="AVAILABLE" ${property.foodOption eq 'AVAILABLE'?'selected':''}>Meal plan available</option><option value="NOT_AVAILABLE" ${property.foodOption eq 'NOT_AVAILABLE'?'selected':''}>No food</option></select></div>
      <div class="field full"><label for="mealDetails">Meal details</label><input id="mealDetails" name="mealDetails" maxlength="500" placeholder="Meal times, vegetarian options, etc." value="<c:out value='${property.mealDetails}'/>"></div>
    </div>
    <h2>Room types and monthly prices</h2>
    <div data-room-list><c:choose><c:when test="${not empty property.roomTypes}"><c:forEach items="${property.roomTypes}" var="room"><div class="room-row">
      <div class="field"><label>Sharing</label><select name="sharing" required><option value="SINGLE" ${room.sharing eq 'SINGLE'?'selected':''}>Single</option><option value="DOUBLE" ${room.sharing eq 'DOUBLE'?'selected':''}>Double</option><option value="TRIPLE" ${room.sharing eq 'TRIPLE'?'selected':''}>Triple</option><option value="FOUR_PLUS" ${room.sharing eq 'FOUR_PLUS'?'selected':''}>4+</option></select></div>
      <div class="field"><label>Monthly rent (₹)</label><input type="number" name="rent" min="0" step="0.01" required value="<c:out value='${room.rent}'/>"></div>
      <div class="field"><label>Deposit (₹)</label><input type="number" name="deposit" min="0" step="0.01" required value="<c:out value='${room.deposit}'/>"></div><span class="mono">ROOM</span>
    </div></c:forEach></c:when><c:otherwise><div class="room-row">
      <div class="field"><label>Sharing</label><select name="sharing" required><option value="SINGLE">Single</option><option value="DOUBLE">Double</option><option value="TRIPLE">Triple</option><option value="FOUR_PLUS">4+</option></select></div>
      <div class="field"><label>Monthly rent (₹)</label><input type="number" name="rent" min="0" step="0.01" required></div>
      <div class="field"><label>Deposit (₹)</label><input type="number" name="deposit" min="0" step="0.01" required></div>
      <span class="mono">ROOM 1</span>
    </div></c:otherwise></c:choose></div>
    <button class="button button-outline" type="button" data-add-room>+ ADD ROOM TYPE</button>
    <h2 class="section-tight">Amenities</h2><div class="check-row field">
      <c:forEach items="${amenityOptions}" var="amenity"><label class="check-row"><input type="checkbox" name="amenities" value="${amenity}"><c:forEach items="${property.amenities}" var="selectedAmenity"><c:if test="${selectedAmenity eq amenity}">checked</c:if></c:forEach><c:out value="${amenity}"/></label></c:forEach>
    </div>
    <h2>House rules and description</h2>
    <div class="form-grid">
      <div class="field"><label for="curfew">Curfew</label><input id="curfew" name="curfew" maxlength="120" placeholder="No curfew / 10:30 pm" value="<c:out value='${property.curfew}'/>"></div>
      <div class="field"><label for="visitorRules">Visitor policy</label><input id="visitorRules" name="visitorRules" maxlength="250" value="<c:out value='${property.visitorRules}'/>"></div>
      <div class="field"><label for="noticePeriod">Notice period</label><input id="noticePeriod" name="noticePeriod" maxlength="80" placeholder="30 days" value="<c:out value='${property.noticePeriod}'/>"></div>
      <div class="field"><label for="maintenanceCharges">Maintenance per month (₹)</label><input id="maintenanceCharges" name="maintenanceCharges" type="number" min="0" step="0.01" value="<c:out value='${empty property ? 0 : property.maintenanceCharges}'/>"></div>
      <div class="field full"><label>House policies</label><div class="check-row"><label class="check-row"><input type="checkbox" name="smokingAllowed" ${property.smokingAllowed?'checked':''}> Smoking allowed</label><label class="check-row"><input type="checkbox" name="alcoholAllowed" ${property.alcoholAllowed?'checked':''}> Alcohol allowed</label><label class="check-row"><input type="checkbox" name="petsAllowed" ${property.petsAllowed?'checked':''}> Pets allowed</label></div></div>
      <div class="field full"><label for="description">Description</label><textarea id="description" name="description" required maxlength="5000" minlength="30"><c:out value="${property.description}"/></textarea></div>
      <div class="field full"><label for="nearbyLandmarks">Nearby landmarks</label><input id="nearbyLandmarks" name="nearbyLandmarks" maxlength="500" placeholder="Transit, campus, shops..." value="<c:out value='${property.nearbyLandmarks}'/>"></div>
    </div>
    <h2>Show the space</h2><div class="field"><label for="photos">Property photos (4–12)</label><input id="photos" name="photos" type="file" accept="image/jpeg,image/png,image/webp" multiple ${empty property?'required':''}><small class="help">${empty property?'Upload 4–12 photos.':'Leave empty to keep the existing photos, or upload 4–12 replacement photos.'} JPEG, PNG or WebP; maximum 5 MB each.</small></div>
    <label class="check-row field"><input type="checkbox" required> <span>I confirm this listing is accurate and I am authorized to advertise it.</span></label>
    <button class="button button-black" type="submit">SUBMIT FOR APPROVAL →</button>
  </form>
</section>
<%@ include file="/WEB-INF/views/fragments/footer.jspf" %>
