<%@ include file="/WEB-INF/views/fragments/head.jspf" %>
<%@ include file="/WEB-INF/views/fragments/header.jspf" %>
<section class="page-shell container">
  <div class="page-intro"><span class="eyebrow">OWNER VERIFICATION · STEP 1 OF 2</span><h1 class="page-title">Show us it's yours.</h1><p>Submit your government ID, a selfie and proof you own or are authorized to list this property. Files are private, stored outside the public website and accessible only to you and NESTIFY administrators.</p></div>
  <c:if test="${not empty error}"><n:alert message="${error}"/></c:if>
  <c:if test="${not empty kyc}"><div class="panel"><div class="status-line"><strong>Current status</strong><n:badge label="${kyc.status}" tone="${kyc.status eq 'APPROVED'?'approved':kyc.status eq 'REJECTED'?'rejected':kyc.status eq 'NEEDS_MORE_INFO'?'needs-info':'pending'}"/></div><c:if test="${not empty kyc.reviewReason}"><p><c:out value="${kyc.reviewReason}"/></p></c:if><c:if test="${kyc.status eq 'APPROVED'}"><p>Your owner identity is verified. You can now create a property listing.</p><a class="button" href="${pageContext.request.contextPath}/owner/listing/new">ADD A LISTING →</a></c:if></div></c:if>
  <form class="form-card" action="${pageContext.request.contextPath}/owner/kyc" method="post" enctype="multipart/form-data">
    <input type="hidden" name="_csrf" value="${sessionScope.csrfToken}">
    <div class="steps"><div><span class="step-number">01</span><strong>Identity</strong></div><div><span class="step-number">02</span><strong>Property proof</strong></div></div>
    <div class="field"><label for="idType">Identity document</label><select id="idType" name="idType" required><option value="AADHAAR">Aadhaar</option><option value="PAN">PAN</option><option value="PASSPORT">Passport</option><option value="DRIVING_LICENCE">Driving licence</option></select></div>
    <div class="field"><label for="idNumber">Document number</label><input id="idNumber" name="idNumber" required maxlength="80" autocomplete="off"></div>
    <div class="form-grid">
      <div class="field"><label for="idFront">ID front image</label><input id="idFront" name="idFront" type="file" accept="image/jpeg,image/png,image/webp" required></div>
      <div class="field"><label for="idBack">ID back image</label><input id="idBack" name="idBack" type="file" accept="image/jpeg,image/png,image/webp" required></div>
      <div class="field"><label for="selfie">Your selfie</label><input id="selfie" name="selfie" type="file" accept="image/jpeg,image/png,image/webp" required></div>
      <div class="field"><label for="ownershipProof">Ownership / authorization proof</label><input id="ownershipProof" name="ownershipProof" type="file" accept="image/jpeg,image/png,image/webp" required><small class="help">Electricity bill, property tax receipt or rent agreement.</small></div>
    </div>
    <label class="check-row field"><input type="checkbox" required> <span>I confirm these details are accurate and I am authorized to list the property.</span></label>
    <button class="button button-black" type="submit">SUBMIT FOR REVIEW →</button>
  </form>
</section>
<%@ include file="/WEB-INF/views/fragments/footer.jspf" %>
