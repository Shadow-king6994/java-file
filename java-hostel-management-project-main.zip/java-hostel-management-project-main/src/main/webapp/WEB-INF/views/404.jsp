<%@ include file="/WEB-INF/views/fragments/head.jspf" %>
<%@ include file="/WEB-INF/views/fragments/header.jspf" %>
<section class="page-shell container"><div class="empty-state"><span class="eyebrow">404 · WRONG ADDRESS</span><h1 class="page-title">Room not found.</h1><p>This page may have moved or the listing is no longer available.</p><a class="button" href="${pageContext.request.contextPath}/search">FIND A ROOM</a></div></section>
<%@ include file="/WEB-INF/views/fragments/footer.jspf" %>
