<%@ include file="/WEB-INF/views/fragments/head.jspf" %>
<%@ include file="/WEB-INF/views/fragments/header.jspf" %>
<section class="page-shell container"><form class="form-card" action="${pageContext.request.contextPath}/auth/register" method="post">
  <span class="eyebrow">LET'S GET YOU SET UP</span><h1>Join the nest.</h1><p>Tenants can start exploring. Owners can list after verification.</p><c:if test="${not empty error}"><n:alert message="${error}"/></c:if>
  <input type="hidden" name="_csrf" value="${sessionScope.csrfToken}">
  <div class="field"><label for="name">Full name</label><input id="name" name="name" required maxlength="120" autocomplete="name"></div>
  <div class="form-grid"><div class="field"><label for="mobile">Mobile number</label><input id="mobile" name="mobile" required pattern="\\+?[0-9]{10,15}" autocomplete="tel"></div><div class="field"><label for="email">Email address</label><input id="email" name="email" type="email" required maxlength="190" autocomplete="email"></div></div>
  <div class="field"><label for="password">Password</label><input id="password" name="password" type="password" required minlength="10" maxlength="72" autocomplete="new-password"><small class="help">Use at least 10 characters.</small></div>
  <fieldset class="field"><legend class="label">I'm here as a</legend><label class="check-row"><input type="radio" name="role" value="TENANT" checked> Tenant — I'm looking for a room</label><label class="check-row"><input type="radio" name="role" value="OWNER"> Owner — I have a place to list</label></fieldset>
  <button class="button button-black" type="submit">CREATE ACCOUNT →</button><p>Already registered? <a href="${pageContext.request.contextPath}/login">Log in.</a></p>
</form></section>
<%@ include file="/WEB-INF/views/fragments/footer.jspf" %>
