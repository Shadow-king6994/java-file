<%@ include file="/WEB-INF/views/fragments/head.jspf" %>
<%@ include file="/WEB-INF/views/fragments/header.jspf" %>
<section class="hero">
  <div class="container hero-grid">
    <div class="hero-copy">
      <span class="eyebrow">ROOMMATES? ROOM READY. NESTIFY.</span>
      <h1 class="headline">A better place<br>to <span class="highlight">belong.</span></h1>
      <p>Find a PG or hostel that feels right. Every owner is verified before their listing goes live.</p>
      <form class="hero-search" action="${pageContext.request.contextPath}/search" method="get">
        <label class="sr-only" for="hero-city">City</label><input id="hero-city" name="city" placeholder="City — Mumbai, Pune..." autocomplete="address-level2">
        <label class="sr-only" for="hero-type">Stay type</label><select id="hero-type" name="type"><option value="">PG OR HOSTEL?</option><option>PG</option><option>HOSTEL</option></select>
        <button class="button button-black" type="submit">FIND YOUR ROOM →</button>
      </form>
    </div>
    <aside class="hero-sticker"><div class="eyebrow">GOOD STAYS START HERE</div><p>REAL OWNERS.<br>REAL PLACES.<br>LESS GUESSWORK.</p><span class="badge badge-mint">VERIFIED BEFORE YOU MOVE IN</span></aside>
  </div>
</section>
<div class="ticker"><div class="ticker-track">MUMBAI ✳ PUNE ✳ BENGALURU ✳ MAKE ROOM FOR YOUR NEXT CHAPTER ✳ MUMBAI ✳ PUNE ✳ BENGALURU ✳ MAKE ROOM FOR YOUR NEXT CHAPTER ✳ MUMBAI ✳ PUNE ✳ BENGALURU ✳</div></div>
<section class="section">
  <div class="container">
    <div class="section-heading"><div><span class="eyebrow">GOOD PLACES, BETTER PEOPLE</span><h2>Featured nests</h2></div><a class="button button-outline" href="${pageContext.request.contextPath}/search">BROWSE ALL →</a></div>
    <div class="grid"><c:forEach items="${featured}" var="property"><n:card property="${property}"/></c:forEach></div>
    <c:if test="${empty featured}"><div class="empty-state"><h3>New stays are landing soon.</h3><p>Try searching by city or check back shortly.</p></div></c:if>
  </div>
</section>
<section class="section section-tight">
  <div class="container"><span class="eyebrow">THREE STEPS. ZERO DRAMA.</span><h2 class="page-title">How it works</h2>
    <div class="steps steps-spaced"><article class="info-block"><span class="step-number">01</span><h3>Find your fit</h3><p>Filter real listings by neighborhood, budget, room type and the things that matter to you.</p></article><article class="info-block"><span class="step-number">02</span><h3>Ask. Visit. Decide.</h3><p>Send an enquiry or request a visit directly with the owner. Your details stay with your conversation.</p></article><article class="info-block"><span class="step-number">03</span><h3>Move in, mind at ease</h3><p>Owner identity and property documents are reviewed before a listing can be approved and shown.</p></article></div>
  </div>
</section>
<section class="section"><div class="container two-col">
  <div class="info-block"><span class="eyebrow">PROOF BEFORE PROMOTION</span><h2 class="page-title">Verification is not a vibe. It's a process.</h2><p>Owners submit identity documents, a selfie and proof they can list the property. Our admin team reviews the files and listing before it becomes public.</p><p><n:badge label="VERIFIED OWNER" tone="verified"/> appears on listings from approved owners. It means documents were reviewed—not that you should skip your own visit and checks.</p></div>
  <div class="callout"><h2>Own a good place?</h2><p>Get verified, share honest details and welcome your next resident.</p><a class="button" href="${pageContext.request.contextPath}/register">START LISTING →</a></div>
</div></section>
<section class="section section-tight faq"><div class="container"><span class="eyebrow">THE QUICK ANSWERS</span><h2 class="page-title">Frequently asked</h2>
  <details><summary>Does NESTIFY charge tenants to browse?</summary><p>Browsing and contacting owners through NESTIFY is free. Any rent, deposit or other charges are agreed directly with the owner.</p></details>
  <details><summary>What does “Verified Owner” mean?</summary><p>The owner supplied identity and ownership or authorization documents which an administrator reviewed. Always verify details yourself before paying or signing.</p></details>
  <details><summary>How do I list a PG or hostel?</summary><p>Create an owner account, verify your email, submit KYC and property proof, then add your listing. Public visibility starts only after review.</p></details>
  <details><summary>Can I report a suspicious listing?</summary><p>Yes. Use the report form on a listing page, and do not share money or sensitive documents until you have independently verified the property and owner.</p></details>
</div></section>
<%@ include file="/WEB-INF/views/fragments/footer.jspf" %>
