<%@ include file="/WEB-INF/views/fragments/head.jspf" %>
<%@ include file="/WEB-INF/views/fragments/header.jspf" %>
<section class="page-shell container"><div class="empty-state"><span class="eyebrow">403 · NOT YOUR DOOR</span><h1 class="page-title">Access denied.</h1><p>You don't have permission to open that page.</p><a class="button" href="${pageContext.request.contextPath}/">GO HOME</a></div></section>
<%@ include file="/WEB-INF/views/fragments/footer.jspf" %>
