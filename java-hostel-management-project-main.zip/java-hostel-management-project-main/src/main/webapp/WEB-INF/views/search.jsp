<%@ include file="/WEB-INF/views/fragments/head.jspf" %>
<%@ include file="/WEB-INF/views/fragments/header.jspf" %>
<section class="page-shell"><div class="container">
  <div class="page-intro"><span class="eyebrow">YOUR NEXT PLACE IS OUT THERE</span><h1 class="page-title">Find your nest.</h1><p>Browse verified PG and hostel listings, then contact the owner directly.</p></div>
  <c:if test="${not empty error}"><n:alert message="${error}"/></c:if>
  <div class="search-layout">
    <form class="filter-panel" action="${pageContext.request.contextPath}/search" method="get">
      <h2>Make it yours</h2>
      <div class="field"><label for="city">City</label><input id="city" name="city" value="<c:out value='${filters.city}'/>" placeholder="Mumbai"></div>
      <div class="field"><label for="locality">Locality</label><input id="locality" name="locality" value="<c:out value='${filters.locality}'/>" placeholder="Andheri"></div>
      <div class="field"><label for="type">PG / Hostel</label><select id="type" name="type"><option value="">Any type</option><option value="PG" ${filters.type eq 'PG'?'selected':''}>PG</option><option value="HOSTEL" ${filters.type eq 'HOSTEL'?'selected':''}>Hostel</option></select></div>
      <div class="field"><label for="gender">Suitable for</label><select id="gender" name="gender"><option value="">Anyone</option><option value="MALE" ${filters.gender eq 'MALE'?'selected':''}>Male</option><option value="FEMALE" ${filters.gender eq 'FEMALE'?'selected':''}>Female</option><option value="COED" ${filters.gender eq 'COED'?'selected':''}>Co-ed</option></select></div>
      <div class="field"><label for="sharing">Room sharing</label><select id="sharing" name="sharing"><option value="">Any sharing</option><option value="SINGLE">Single</option><option value="DOUBLE">Double</option><option value="TRIPLE">Triple</option><option value="FOUR_PLUS">4+</option></select></div>
      <div class="field"><label for="amenity">Amenity</label><select id="amenity" name="amenity"><option value="">Any amenity</option><option>WiFi</option><option>AC</option><option>Laundry</option><option>Power backup</option><option>CCTV</option><option>Geyser</option><option>Parking</option><option>Housekeeping</option><option>Attached bath</option><option>Fridge</option><option>TV</option><option>Study table</option></select></div>
      <div class="form-grid"><div class="field"><label for="minPrice">Rent from</label><input id="minPrice" name="minPrice" type="number" min="0" step="100" value="<c:out value='${filters.minPrice}'/>"></div><div class="field"><label for="maxPrice">To</label><input id="maxPrice" name="maxPrice" type="number" min="0" step="100" value="<c:out value='${filters.maxPrice}'/>"></div></div>
      <div class="field"><label for="food">Food</label><select id="food" name="food"><option value="">Any</option><option value="INCLUDED" ${filters.food eq 'INCLUDED'?'selected':''}>Included</option><option value="AVAILABLE" ${filters.food eq 'AVAILABLE'?'selected':''}>Available</option><option value="NOT_AVAILABLE" ${filters.food eq 'NOT_AVAILABLE'?'selected':''}>Not available</option></select></div>
      <div class="field"><label for="sort">Sort</label><select id="sort" name="sort"><option value="NEWEST">Newest</option><option value="RENT">Rent: low to high</option></select></div>
      <label class="check-row field"><input type="checkbox" name="verified" value="on" ${not empty filters.verified?'checked':''}> <span>Verified owner only</span></label>
      <button class="button button-black" type="submit">APPLY FILTERS</button> <a class="text-link" href="${pageContext.request.contextPath}/search">CLEAR</a>
    </form>
    <div>
      <div class="results-header"><strong><span class="mono">CURATED FOR YOU</span></strong><span class="mono">PAGE <c:out value="${page}"/></span></div>
      <c:choose><c:when test="${not empty properties}"><div class="grid"><c:forEach items="${properties}" var="property"><n:card property="${property}"/></c:forEach></div><n:pagination page="${page}" hasNext="${hasNext}"/></c:when>
      <c:otherwise><div class="empty-state"><h2>No rooms match those filters.</h2><p>Try a wider budget or another neighborhood.</p><a class="button" href="${pageContext.request.contextPath}/search">RESET SEARCH</a></div></c:otherwise></c:choose>
    </div>
  </div>
</div></section>
<%@ include file="/WEB-INF/views/fragments/footer.jspf" %>
