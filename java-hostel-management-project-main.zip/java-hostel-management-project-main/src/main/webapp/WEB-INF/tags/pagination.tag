<%@ tag body-content="empty" %>
<%@ attribute name="page" required="true" type="java.lang.Integer" %>
<%@ attribute name="hasNext" required="true" type="java.lang.Boolean" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<nav class="pagination" aria-label="Search result pages">
  <c:if test="${page gt 1}"><c:url var="previousUrl" value="/search"><c:forEach items="${pageContext.request.parameterMap}" var="parameter"><c:if test="${parameter.key ne 'page'}"><c:forEach items="${parameter.value}" var="value"><c:param name="${parameter.key}" value="${value}"/></c:forEach></c:if></c:forEach><c:param name="page" value="${page - 1}"/></c:url><a class="button button-outline" href="${previousUrl}">← PREVIOUS</a></c:if>
  <span class="mono">PAGE <c:out value="${page}"/></span>
  <c:if test="${hasNext}"><c:url var="nextUrl" value="/search"><c:forEach items="${pageContext.request.parameterMap}" var="parameter"><c:if test="${parameter.key ne 'page'}"><c:forEach items="${parameter.value}" var="value"><c:param name="${parameter.key}" value="${value}"/></c:forEach></c:if></c:forEach><c:param name="page" value="${page + 1}"/></c:url><a class="button button-outline" href="${nextUrl}">NEXT →</a></c:if>
</nav>
