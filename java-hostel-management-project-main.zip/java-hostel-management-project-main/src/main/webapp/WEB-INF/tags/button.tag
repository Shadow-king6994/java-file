<%@ tag body-content="empty" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ attribute name="label" required="true" type="java.lang.String" %>
<%@ attribute name="href" required="false" type="java.lang.String" %>
<%@ attribute name="tone" required="false" type="java.lang.String" %>
<a class="button ${empty tone ? '' : tone}" href="${pageContext.request.contextPath}${href}"><c:out value="${label}"/></a>
