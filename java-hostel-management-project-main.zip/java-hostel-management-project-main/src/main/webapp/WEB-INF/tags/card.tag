<%@ tag body-content="empty" %>
<%@ attribute name="property" required="true" type="com.nestify.model.Property" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="samplePhoto" value="${pageContext.request.contextPath}/assets/images/stay-${property.id mod 4 + 1}.jpg"/>
<article class="listing-card">
  <a class="listing-image" href="${pageContext.request.contextPath}/listing?id=${property.id}" aria-label="View ${property.title}">
    <c:choose><c:when test="${not empty property.photos}"><img src="${pageContext.request.contextPath}/files/${property.photos[0].filePath}" alt="Room at ${property.title}" loading="lazy"></c:when>
    <c:otherwise><img src="${samplePhoto}" alt="Sample accommodation photo" loading="lazy"></c:otherwise></c:choose>
  </a>
  <div class="listing-card-body">
    <div class="badge-row"><span class="badge badge-blue"><c:out value="${property.propertyType}"/></span><span class="badge badge-mint"><c:out value="${property.suitableFor}"/></span><c:if test="${property.verifiedOwner}"><span class="badge badge-verified">VERIFIED ✔</span></c:if></div>
    <h3><a href="${pageContext.request.contextPath}/listing?id=${property.id}"><c:out value="${property.title}"/></a></h3>
    <p><c:out value="${property.locality}"/>, <c:out value="${property.city}"/></p>
    <strong class="price">₹<c:out value="${property.startingRent}"/><small> / month onwards</small></strong>
    <p class="listing-owner">HOSTED BY <c:out value="${property.ownerName}"/></p>
    <a class="text-link" href="${pageContext.request.contextPath}/listing?id=${property.id}">VIEW ROOM →</a>
  </div>
</article>
