<%@ tag body-content="empty" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ attribute name="message" required="true" type="java.lang.String" %>
<%@ attribute name="kind" required="false" type="java.lang.String" %>
<div class="alert ${empty kind ? 'alert-error' : 'alert-'.concat(kind)}" role="status"><c:out value="${message}"/></div>
