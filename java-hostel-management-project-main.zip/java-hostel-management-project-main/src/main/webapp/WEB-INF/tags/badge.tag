<%@ tag body-content="empty" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ attribute name="label" required="true" type="java.lang.String" %>
<%@ attribute name="tone" required="false" type="java.lang.String" %>
<span class="badge ${empty tone ? 'badge-yellow' : 'badge-'.concat(tone)}"><c:out value="${label}"/></span>
