Sample listing photos

These locally bundled photos illustrate sample/demo listings only. They are not
photographs of the addresses, properties, or hosts shown with demo content.
Replace them with the owner's verified property photos for real listings.

All four images are served from Pexels' image CDN and are available under the
Pexels license (https://www.pexels.com/license/), which allows use on websites
and apps:

stay-1.jpg: https://www.pexels.com/photo/1642125/
stay-2.jpg: https://www.pexels.com/photo/1454806/
stay-3.jpg: https://www.pexels.com/photo/271618/
stay-4.jpg: https://www.pexels.com/photo/276724/
