document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("[data-modal-open]").forEach(button => {
    button.addEventListener("click", () => {
      const modal = document.getElementById(button.getAttribute("data-modal-open"));
      if (modal instanceof HTMLDialogElement) modal.showModal();
    });
  });
  document.querySelectorAll("[data-modal-close]").forEach(button => {
    button.addEventListener("click", () => {
      const modal = button.closest("dialog");
      if (modal instanceof HTMLDialogElement) modal.close();
    });
  });
  const addRoom = document.querySelector("[data-add-room]");
  const roomList = document.querySelector("[data-room-list]");
  if (addRoom && roomList) {
    addRoom.addEventListener("click", () => {
      if (roomList.querySelectorAll(".room-row").length >= 4) return;
      const row = document.createElement("div");
      row.className = "room-row";
      row.innerHTML = '<div class="field"><label>Sharing</label><select name="sharing" required><option value="SINGLE">Single</option><option value="DOUBLE">Double</option><option value="TRIPLE">Triple</option><option value="FOUR_PLUS">4+</option></select></div><div class="field"><label>Monthly rent (₹)</label><input type="number" name="rent" min="0" step="0.01" required></div><div class="field"><label>Deposit (₹)</label><input type="number" name="deposit" min="0" step="0.01" required></div><button class="button button-pink" type="button" data-remove-room aria-label="Remove room type">REMOVE</button>';
      roomList.append(row);
    });
    roomList.addEventListener("click", event => {
      const target = event.target;
      if (target instanceof HTMLElement && target.matches("[data-remove-room]") && roomList.querySelectorAll(".room-row").length > 1) target.closest(".room-row").remove();
    });
  }
});
