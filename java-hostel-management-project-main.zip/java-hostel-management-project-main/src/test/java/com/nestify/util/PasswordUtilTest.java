package com.nestify.util;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class PasswordUtilTest {
    @Test void hashesAndVerifiesWithoutStoringPlaintext(){
        String hash=PasswordUtil.hash("NestifySecure#2026");
        assertNotEquals("NestifySecure#2026",hash);
        assertTrue(PasswordUtil.matches("NestifySecure#2026",hash));
        assertFalse(PasswordUtil.matches("wrong-password",hash));
    }
}
