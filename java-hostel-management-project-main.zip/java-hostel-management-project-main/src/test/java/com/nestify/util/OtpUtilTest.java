package com.nestify.util;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class OtpUtilTest {
    @Test void generatesSixDigitCodesAndComparesHashedValues(){
        String otp=OtpUtil.generate(),hash=OtpUtil.hash(otp);
        assertTrue(otp.matches("\\d{6}"));
        assertNotEquals(otp,hash);
        assertTrue(OtpUtil.matches(otp,hash));
        assertFalse(OtpUtil.matches("000000",hash));
    }
}
