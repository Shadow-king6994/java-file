package com.nestify.service;
import com.nestify.dao.PropertyDao;
import com.nestify.model.Photo;
import com.nestify.model.Property;
import com.nestify.model.RoomType;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.Map;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
class ListingServiceTest {
    private final PropertyDao dao=mock(PropertyDao.class);
    private final ListingService service=new ListingService(dao);
    @Test void rejectsInvalidSearchEnumsBeforeQuery(){
        assertThrows(IllegalArgumentException.class,()->service.search(Map.of("type","PG' OR 1=1"),1));
        verifyNoInteractions(dao);
    }
    @Test void listingRequiresFourPhotosAndAtLeastOnePricedRoom(){
        Property property=validProperty();
        RoomType room=new RoomType();room.setSharing("DOUBLE");room.setRent(new BigDecimal("10000"));room.setDeposit(new BigDecimal("20000"));room.setAvailableCount(1);property.getRoomTypes().add(room);
        IllegalArgumentException error=assertThrows(IllegalArgumentException.class,()->service.create(property));
        assertTrue(error.getMessage().contains("4 to 12"));
        verifyNoInteractions(dao);
    }
    @Test void validListingIsPassedToDao(){
        Property property=validProperty();
        RoomType room=new RoomType();room.setSharing("SINGLE");room.setRent(new BigDecimal("15000"));room.setDeposit(new BigDecimal("30000"));room.setAvailableCount(1);property.getRoomTypes().add(room);
        for(int i=0;i<4;i++){Photo photo=new Photo();photo.setFilePath("properties/"+i+".jpg");property.getPhotos().add(photo);}
        when(dao.create(property)).thenReturn(42L);
        assertEquals(42L,service.create(property));
        verify(dao).create(property);
    }
    private Property validProperty(){
        Property p=new Property();p.setOwnerId(2);p.setTitle("A real room listing");p.setPropertyType("PG");p.setSuitableFor("COED");p.setCity("Pune");p.setLocality("Kothrud");p.setFullAddress("12 Test Street, Kothrud");p.setPincode("411038");p.setTotalRooms(4);p.setAvailableFrom(Date.valueOf("2030-01-01"));p.setFoodOption("AVAILABLE");p.setDescription("A complete and accurate description for an example listing.");return p;
    }
}
