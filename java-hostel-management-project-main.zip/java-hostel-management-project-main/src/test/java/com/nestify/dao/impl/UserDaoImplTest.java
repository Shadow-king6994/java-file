package com.nestify.dao.impl;
import com.nestify.util.ConnectionProvider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
class UserDaoImplTest {
    @Test void findByEmailUsesPreparedParameterAndMapsUser()throws Exception{
        Connection connection=mock(Connection.class);PreparedStatement statement=mock(PreparedStatement.class);ResultSet result=mock(ResultSet.class);
        when(connection.prepareStatement("SELECT * FROM users WHERE email=?")).thenReturn(statement);when(statement.executeQuery()).thenReturn(result);when(result.next()).thenReturn(true);
        when(result.getLong("id")).thenReturn(15L);when(result.getString("name")).thenReturn("Alex");when(result.getString("mobile")).thenReturn("9876543210");when(result.getString("email")).thenReturn("alex@example.com");when(result.getString("password_hash")).thenReturn("$2a$hash");when(result.getString("role")).thenReturn("TENANT");when(result.getString("status")).thenReturn("ACTIVE");when(result.getBoolean("email_verified")).thenReturn(true);
        ConnectionProvider provider=()->connection;
        var user=new UserDaoImpl(provider).findByEmail("alex@example.com").orElseThrow();
        assertEquals(15,user.getId());assertEquals("TENANT",user.getRole());assertEquals("ACTIVE",user.getStatus());assertTrue(user.isEmailVerified());
        verify(statement).setString(1,"alex@example.com");
    }
}
