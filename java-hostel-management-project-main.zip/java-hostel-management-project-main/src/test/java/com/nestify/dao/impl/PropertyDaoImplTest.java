package com.nestify.dao.impl;
import com.nestify.util.ConnectionProvider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
class PropertyDaoImplTest {
    @Test void searchBindsUntrustedCityInsteadOfAppendingItToSql()throws Exception{
        String input="' OR 1=1 --";
        Connection connection=mock(Connection.class);PreparedStatement statement=mock(PreparedStatement.class);ResultSet result=mock(ResultSet.class);
        when(connection.prepareStatement(anyString())).thenReturn(statement);when(statement.executeQuery()).thenReturn(result);when(result.next()).thenReturn(false);
        PropertyDaoImpl dao=new PropertyDaoImpl((ConnectionProvider)()->connection);
        assertTrue(dao.search(Map.of("city",input),1,12).isEmpty());
        ArgumentCaptor<String> sql=ArgumentCaptor.forClass(String.class);verify(connection).prepareStatement(sql.capture());
        assertFalse(sql.getValue().contains(input));assertTrue(sql.getValue().contains("p.city=?"));
        verify(statement).setObject(1,input);
    }
}
