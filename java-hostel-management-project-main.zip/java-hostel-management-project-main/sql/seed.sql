USE nestify;
-- Seed principals have unusable passwords and are disabled until explicitly bootstrapped.
-- Set admin.email=admin@nestify.local and a strong admin.password in NESTIFY_CONFIG.
INSERT IGNORE INTO users(id,name,mobile,email,password_hash,role,email_verified,status) VALUES
(1,'NESTIFY Demo Owner','9000000001','demo-owner@nestify.local','!','OWNER',TRUE,'DISABLED'),
(2,'NESTIFY Administrator','9999999999','admin@nestify.local','!','ADMIN',TRUE,'DISABLED');
INSERT IGNORE INTO owner_kyc(user_id,id_type,id_number,id_front_path,id_back_path,selfie_path,ownership_proof_path,status)
VALUES(1,'PAN','DEMO-VERIFIED','demo/kyc/front','demo/kyc/back','demo/kyc/selfie','demo/kyc/proof','APPROVED');
INSERT IGNORE INTO properties(id,owner_id,title,property_type,suitable_for,city,locality,full_address,pincode,total_rooms,available_from,food_option,meal_details,description,nearby_landmarks,status)
VALUES
(1,1,'Bright co-living near Andheri station','PG','COED','Mumbai','Andheri East','Demo listing address, Andheri East','400069',18,'2026-11-01','INCLUDED','Breakfast and dinner','Verified, furnished rooms with shared community spaces and secure access.','Metro, station, local markets','APPROVED'),
(2,1,'Quiet women’s residence in Powai','HOSTEL','FEMALE','Mumbai','Powai','Demo listing address, Powai','400076',22,'2026-11-01','AVAILABLE','Optional meal plan','A calm, well-maintained home close to offices and colleges.','Hiranandani, IIT Bombay','APPROVED'),
(3,1,'Budget double sharing in Dadar','PG','MALE','Mumbai','Dadar West','Demo listing address, Dadar West','400028',12,'2026-11-01','NOT_AVAILABLE',NULL,'Clean, connected and thoughtfully managed shared rooms.','Dadar station, Shivaji Park','APPROVED'),
(4,1,'Student-friendly stay in Viman Nagar','PG','COED','Pune','Viman Nagar','Demo listing address, Viman Nagar','411014',20,'2026-11-01','INCLUDED','Vegetarian meals','A bright stay near campus with reliable WiFi and study areas.','Symbiosis, Phoenix Marketcity','APPROVED'),
(5,1,'Women’s hostel near FC Road','HOSTEL','FEMALE','Pune','Shivajinagar','Demo listing address, Shivajinagar','411005',28,'2026-11-01','AVAILABLE','Meal plans available','Secure hostel with housekeeping and shared lounge.','FC Road, Deccan','APPROVED'),
(6,1,'Modern PG in Hinjawadi Phase 1','PG','MALE','Pune','Hinjawadi','Demo listing address, Hinjawadi','411057',30,'2026-11-01','INCLUDED','Breakfast and dinner','Easy commute, comfortable rooms and power backup.','IT Park, bus stop','APPROVED'),
(7,1,'Co-living close to Koramangala 5th Block','PG','COED','Bengaluru','Koramangala','Demo listing address, Koramangala','560095',16,'2026-11-01','AVAILABLE','Meal add-on','Social, secure and fully furnished shared living.','Forum Mall, 80 Feet Road','APPROVED'),
(8,1,'Peaceful women’s hostel in Indiranagar','HOSTEL','FEMALE','Bengaluru','Indiranagar','Demo listing address, Indiranagar','560038',24,'2026-11-01','INCLUDED','Three meals','Comfortable rooms in a residential neighborhood.','Metro, 100 Feet Road','APPROVED'),
(9,1,'Affordable PG in Whitefield','PG','MALE','Bengaluru','Whitefield','Demo listing address, Whitefield','560066',32,'2026-11-01','NOT_AVAILABLE',NULL,'Practical, clean accommodation near major workplaces.','ITPL, metro','APPROVED'),
(10,1,'Premium hostel in Bandra West','HOSTEL','COED','Mumbai','Bandra West','Demo listing address, Bandra West','400050',14,'2026-11-01','AVAILABLE','Optional meal plan','Design-forward rooms with round-the-clock security.','Bandra station, Linking Road','APPROVED'),
(11,1,'Shared living near Kothrud depot','PG','FEMALE','Pune','Kothrud','Demo listing address, Kothrud','411038',18,'2026-11-01','INCLUDED','Breakfast','Friendly shared living with daily housekeeping.','Kothrud depot, MIT','APPROVED'),
(12,1,'Co-living in HSR Layout','PG','COED','Bengaluru','HSR Layout','Demo listing address, HSR Layout','560102',26,'2026-11-01','INCLUDED','Breakfast and dinner','Secure, spacious home with excellent connectivity.','Agara Lake, Outer Ring Road','APPROVED');
INSERT IGNORE INTO room_types(property_id,sharing,rent,deposit,available_count) VALUES
(1,'DOUBLE',14500,30000,3),(2,'DOUBLE',16000,32000,4),(3,'TRIPLE',9500,15000,2),(4,'DOUBLE',12000,24000,4),
(5,'DOUBLE',13500,27000,5),(6,'SINGLE',18000,36000,3),(7,'DOUBLE',15500,30000,3),(8,'TRIPLE',11000,22000,4),
(9,'DOUBLE',12500,25000,5),(10,'SINGLE',22000,44000,2),(11,'DOUBLE',11500,20000,3),(12,'DOUBLE',15000,30000,4);
INSERT IGNORE INTO property_amenities(property_id,amenity_id)
SELECT p.id,a.id FROM properties p JOIN amenities a ON a.name IN ('WiFi','CCTV','Housekeeping','Study table') WHERE p.id BETWEEN 1 AND 12;
