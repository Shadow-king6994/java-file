CREATE DATABASE IF NOT EXISTS nestify CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE nestify;

CREATE TABLE IF NOT EXISTS users (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(120) NOT NULL, mobile VARCHAR(20) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE, password_hash VARCHAR(100) NOT NULL,
 role ENUM('TENANT','OWNER','ADMIN') NOT NULL, email_verified BOOLEAN NOT NULL DEFAULT FALSE,
 status ENUM('ACTIVE','LOCKED','DISABLED') NOT NULL DEFAULT 'ACTIVE', failed_logins INT NOT NULL DEFAULT 0,
 lock_until DATETIME NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_users_role_status(role,status), INDEX idx_users_created(created_at)
);
CREATE TABLE IF NOT EXISTS owner_kyc (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, user_id BIGINT NOT NULL UNIQUE,
 id_type ENUM('AADHAAR','PAN','PASSPORT','DRIVING_LICENCE') NOT NULL, id_number VARCHAR(80) NOT NULL,
 id_front_path VARCHAR(500) NOT NULL, id_back_path VARCHAR(500) NOT NULL, selfie_path VARCHAR(500) NOT NULL,
 ownership_proof_path VARCHAR(500) NOT NULL,
 status ENUM('PENDING','APPROVED','REJECTED','NEEDS_MORE_INFO') NOT NULL DEFAULT 'PENDING',
 review_reason VARCHAR(1000), reviewed_by BIGINT NULL, reviewed_at DATETIME NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(reviewed_by) REFERENCES users(id),
 INDEX idx_kyc_status_created(status,created_at)
);
CREATE TABLE IF NOT EXISTS properties (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, owner_id BIGINT NOT NULL, title VARCHAR(180) NOT NULL,
 property_type ENUM('PG','HOSTEL') NOT NULL, suitable_for ENUM('MALE','FEMALE','COED') NOT NULL,
 city VARCHAR(100) NOT NULL, locality VARCHAR(120) NOT NULL, full_address VARCHAR(500) NOT NULL,
 pincode CHAR(6) NOT NULL, total_rooms INT NOT NULL, available_from DATE NOT NULL,
 food_option ENUM('INCLUDED','AVAILABLE','NOT_AVAILABLE') NOT NULL, meal_details VARCHAR(500),
 curfew VARCHAR(120), visitor_rules VARCHAR(250), smoking_allowed BOOLEAN NOT NULL DEFAULT FALSE,
 alcohol_allowed BOOLEAN NOT NULL DEFAULT FALSE, pets_allowed BOOLEAN NOT NULL DEFAULT FALSE,
 notice_period VARCHAR(80), maintenance_charges DECIMAL(10,2) NOT NULL DEFAULT 0,
 description TEXT NOT NULL, nearby_landmarks VARCHAR(500), status ENUM('DRAFT','PENDING','APPROVED','REJECTED','NEEDS_MORE_INFO') NOT NULL DEFAULT 'DRAFT',
 review_reason VARCHAR(1000), reviewed_by BIGINT NULL, reviewed_at DATETIME NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY(owner_id) REFERENCES users(id), FOREIGN KEY(reviewed_by) REFERENCES users(id),
 INDEX idx_properties_search(city,property_type,status), INDEX idx_properties_status_created(status,created_at),
 INDEX idx_properties_available(available_from), FULLTEXT INDEX idx_properties_text(title,city,locality,description)
);
CREATE TABLE IF NOT EXISTS room_types (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, property_id BIGINT NOT NULL,
 sharing ENUM('SINGLE','DOUBLE','TRIPLE','FOUR_PLUS') NOT NULL,
 rent DECIMAL(10,2) NOT NULL, deposit DECIMAL(10,2) NOT NULL,
 available_count INT NOT NULL DEFAULT 1,
 FOREIGN KEY(property_id) REFERENCES properties(id) ON DELETE CASCADE,
 INDEX idx_room_price(rent,property_id)
);
CREATE TABLE IF NOT EXISTS property_photos (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, property_id BIGINT NOT NULL, file_path VARCHAR(500) NOT NULL,
 is_cover BOOLEAN NOT NULL DEFAULT FALSE, sort_order INT NOT NULL DEFAULT 0,
 FOREIGN KEY(property_id) REFERENCES properties(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS amenities (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(80) NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS property_amenities (
 property_id BIGINT NOT NULL, amenity_id BIGINT NOT NULL,
 PRIMARY KEY(property_id,amenity_id), FOREIGN KEY(property_id) REFERENCES properties(id) ON DELETE CASCADE,
 FOREIGN KEY(amenity_id) REFERENCES amenities(id)
);
CREATE TABLE IF NOT EXISTS enquiries (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, property_id BIGINT NOT NULL, tenant_id BIGINT NULL,
 name VARCHAR(120) NOT NULL, mobile VARCHAR(20) NOT NULL, email VARCHAR(190) NOT NULL,
 gender ENUM('MALE','FEMALE','OTHER') NOT NULL, occupation ENUM('STUDENT','WORKING','OTHER') NOT NULL,
 college_company VARCHAR(180), move_in_date DATE, stay_duration VARCHAR(60), room_interest VARCHAR(30),
 budget DECIMAL(10,2), message VARCHAR(2000) NOT NULL, preferred_visit_date DATE, preferred_visit_slot VARCHAR(50),
 status ENUM('NEW','CONTACTED','CLOSED') NOT NULL DEFAULT 'NEW',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(property_id) REFERENCES properties(id), FOREIGN KEY(tenant_id) REFERENCES users(id) ON DELETE SET NULL,
 INDEX idx_enquiry_property_created(property_id,created_at), INDEX idx_enquiry_tenant(tenant_id,created_at)
);
CREATE TABLE IF NOT EXISTS visits (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, property_id BIGINT NOT NULL, tenant_id BIGINT NOT NULL,
 requested_date DATE NOT NULL, time_slot VARCHAR(50) NOT NULL, status ENUM('PENDING','CONFIRMED','DECLINED','CANCELLED') NOT NULL DEFAULT 'PENDING',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(property_id) REFERENCES properties(id),
 FOREIGN KEY(tenant_id) REFERENCES users(id), INDEX idx_visit_property(property_id,status)
);
CREATE TABLE IF NOT EXISTS favourites (
 user_id BIGINT NOT NULL, property_id BIGINT NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(user_id,property_id), FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(property_id) REFERENCES properties(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS reports (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, property_id BIGINT NOT NULL, reporter_id BIGINT NULL,
 reason VARCHAR(120) NOT NULL, details VARCHAR(1500), status ENUM('OPEN','REVIEWED','DISMISSED') NOT NULL DEFAULT 'OPEN',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(property_id) REFERENCES properties(id), FOREIGN KEY(reporter_id) REFERENCES users(id) ON DELETE SET NULL,
 INDEX idx_reports_status(status,created_at)
);
CREATE TABLE IF NOT EXISTS admin_actions (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, admin_id BIGINT NOT NULL, target_type VARCHAR(40) NOT NULL,
 target_id BIGINT NOT NULL, action VARCHAR(60) NOT NULL, reason VARCHAR(1000),
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(admin_id) REFERENCES users(id),
 INDEX idx_audit_created(created_at)
);
CREATE TABLE IF NOT EXISTS notifications (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, user_id BIGINT NOT NULL, subject VARCHAR(180) NOT NULL,
 body VARCHAR(1000) NOT NULL, is_read BOOLEAN NOT NULL DEFAULT FALSE,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 INDEX idx_notifications_user(user_id,is_read,created_at)
);
CREATE TABLE IF NOT EXISTS otp_tokens (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, user_id BIGINT NOT NULL, token_hash VARCHAR(100) NOT NULL,
 expires_at DATETIME NOT NULL, consumed_at DATETIME NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, INDEX idx_otp_user_expiry(user_id,expires_at)
);
INSERT IGNORE INTO amenities(name) VALUES ('WiFi'),('AC'),('Laundry'),('Power backup'),('CCTV'),('Geyser'),('Parking'),('Housekeeping'),('Attached bath'),('Fridge'),('TV'),('Study table');
